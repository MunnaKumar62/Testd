/**
 * BadRequestException.java
 *
 * @author [karthik]
 * @version 1.0
 * @date [21/10/2023]
 *
 * Description:
 * This file defines the BadRequestException class, which is used to represent
 * a custom exception for handling bad requests in the application.
 */

package com.abc.assistedJourney.exception;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatusCode;
@Getter
@Setter
public class BadRequestException extends RuntimeException  {

	private HttpStatusCode code;
	private String reason;

	public BadRequestException(HttpStatusCode code, String reason) {
		super(reason);
		this.code = code;
		this.reason = reason;
	}

	public BadRequestException(String reason) {
		super(reason);
		this.reason = reason;
	}
	
}
