package com.abc.assistedJourney.model.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDetailsRequestDTO {
    private String employeeId;
    private String dsaCode;
    private String constitutionType;
}