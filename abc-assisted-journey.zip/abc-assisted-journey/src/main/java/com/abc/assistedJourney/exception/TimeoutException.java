package com.abc.assistedJourney.exception;

import org.springframework.http.HttpStatusCode;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TimeoutException extends RuntimeException {

	private HttpStatusCode code;
	private String reason;

	public TimeoutException(HttpStatusCode code, String reason) {
		super(reason);
		this.code = code;
		this.reason = reason;
	}

	public TimeoutException(String reason) {
		super(reason);
		this.reason = reason;
	}

}
