package com.abc.assistedJourney.repository.command;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.abc.assistedJourney.entity.UserDetails;

@Repository
public interface UserDetailsRepository extends JpaRepository<UserDetails, Long> {
    Optional<UserDetails> findByEmployeeId(String employeeId);
    Optional<UserDetails> findByDsaCodeAndConstitutionType(String dsaCode, String constitutionType);
}
