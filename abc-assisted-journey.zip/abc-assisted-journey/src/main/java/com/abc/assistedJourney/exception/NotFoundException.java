package com.abc.assistedJourney.exception;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatusCode;

@Getter
@Setter
public class NotFoundException extends RuntimeException {

    private HttpStatusCode code;
    private String reason;

    public NotFoundException(HttpStatusCode code, String reason) {
        super(reason);
        this.code = code;
        this.reason = reason;
    }

    public NotFoundException(String reason) {
        super(reason);
        this.reason = reason;
    }
}
