package com.abc.assistedJourney.service.impl;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
<<<<<<< HEAD
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Optional;
=======
import java.util.*;
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26

import com.abc.assistedJourney.common.constants.Constants;
import com.abc.assistedJourney.common.model.SuccessResponse;
import com.abc.assistedJourney.common.util.CommonUtil;
import com.abc.assistedJourney.entity.HelpIssueFilter;
import com.abc.assistedJourney.entity.Lead;
import com.abc.assistedJourney.entity.LeadCustomer;
import com.abc.assistedJourney.exception.CustomException;
import com.abc.assistedJourney.handler.CommandHandler;
import com.abc.assistedJourney.handler.QueryHandler;
import com.abc.assistedJourney.model.*;
<<<<<<< HEAD
=======
import com.abc.assistedJourney.model.response.CommunicationChannel;
import com.abc.assistedJourney.model.response.TotalLeadsResponse;
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
import com.abc.core.common.exception.CommonExceptionHandler;
import com.abc.core.common.exception.InternalException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.abc.assistedJourney.common.util.ChecksumUtils;
import com.abc.assistedJourney.model.response.ChecksumResponse;
import com.abc.assistedJourney.model.response.EmployeeValidateResponse;
import com.abc.assistedJourney.service.LeadService;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class LeadServiceImpl implements LeadService {

	@Autowired
	RestTemplate restTemplate;

	@Value("${aj.validate.url}")
	private String employeeValidateUrl;
<<<<<<< HEAD
	
	@Value("${aj.checksum.url}")
	private String checksumUrl;
	
=======

	@Value("${aj.checksum.url}")
	private String checksumUrl;

>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
	@Autowired
	private ChecksumUtils checksumUtils;
	@Autowired
	private CommonExceptionHandler handler;

	@Autowired
	private QueryHandler queryHandler;

	@Autowired
	private CommandHandler commandHandler;

	@Autowired
	private ApiStatusServiceImpl apiStatusServiceImpl;

	@Autowired
	ObjectMapper objectMapper;

	@Value("${aj.lead.search.url}")
	private String leadSearchApiUrl;

	@Value("${aj.create.lead.url}")
	private String createCustomerApiUrl;

	@Value("${aj.create.lead.consent.url}")
	private String createLeadWithConsentApiUrl;


	@Override
	public LeadResponse searchLead(String phoneNumber) throws Exception {
		log.info("Starting lead search for phone number: {}", phoneNumber);
		ResponseEntity<LeadResponse> response = null;
		Timestamp startTime = CommonUtil.getCurrentTimestamp();

		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Object> entityHeader = new HttpEntity<>(phoneNumber, headers);

			/* response = restTemplate.exchange(leadSearchApiUrl, HttpMethod.POST,
			 * entityHeader, LeadResponse.class);
			 *
			 * if (response == null || response.getBody() == null) { throw new
			 * CustomException("AJ3000", Constants.SEARCH_LEAD + "");
			 *
			 *
			 * }
			 *
			 * LeadResponse leadResponse = response.getBody();
			 */
			//  saveOrUpdateLead(leadResponse);

			Timestamp endTime = CommonUtil.getCurrentTimestamp();
//	        apiStatusServiceImpl.saveApiStatus("LEAD_SEARCH_API", response.getStatusCode().value(), phoneNumber,
//	                response.getBody(), startTime, endTime);
//	        apiStatusServiceImpl.saveApiStatus(Constants.SEARCH_LEAD,
//					response.getStatusCode().value(), requestJson, responseJson, startTime, endTime, userId,
//					leadId);

			log.info("Lead search completed successfully for phone number: {}", phoneNumber);
			// return leadResponse;
			return new LeadResponse("fname","987654328","abc@gmail.com", LocalDate.now());


		} catch (CustomException ex) {
			log.error(ex.getMessage());
			handler.handleException(ex, Constants.SEARCH_LEAD, "");
		} catch (HttpClientErrorException | HttpServerErrorException ex) {
			log.error("Exception in Lead search API : " + ex.getResponseBodyAsString());
			handler.handleException(ex, Constants.SEARCH_LEAD, "");
		} catch (Exception ex) {
			log.error("Exception in Lead search API :" + ex.getMessage());
			handler.handleException(new InternalException("AJ3100", ex), Constants.SEARCH_LEAD, "");
		}
		return null;
	}

	private void saveOrUpdateLead(LeadResponse leadResponse) {
		Lead existingLead = queryHandler.getLeadByMobileNumber(leadResponse.getMobileNumber());

		if (existingLead==null) {
			Lead newLead = new Lead();
			newLead.setFullName(leadResponse.getFullName());
			newLead.setMobileNumber(leadResponse.getMobileNumber());
			newLead.setEmailId(leadResponse.getEmailId());
			newLead.setDob(leadResponse.getDob());
			commandHandler.saveLead(newLead);
			log.info("Lead information saved/updated for phone number: {}", leadResponse.getMobileNumber());
		} else {
			throw new CustomException("AJ3001", Constants.SAVE_OR_UPDATE_LEAD + "");
		}

	}

	@Override
	public ResponseEntity<SuccessResponse> createCustomer(LeadRequest leadRequest) throws Exception {
		log.info("Starting createLead: {}", leadRequest);
		Timestamp startTime = CommonUtil.getCurrentTimestamp();
		SuccessResponse successResponse = null;
		ResponseEntity<LeadResponse> response = null;

		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Object> entityHeader = new HttpEntity<>(leadRequest, headers);

//	        response = restTemplate.exchange(createCustomerApiUrl, HttpMethod.POST, entityHeader, LeadResponse.class);
//	        Timestamp endTime = CommonUtil.getCurrentTimestamp();

			LeadCustomer leadCustomer = new LeadCustomer();
			leadCustomer.setFullName(leadRequest.getFullName());
			leadCustomer.setMobileNumber(leadRequest.getMobileNumber());
			leadCustomer.setEmailId(leadRequest.getEmailId());
			leadCustomer.setDob(leadRequest.getDob());
			leadCustomer.setChannelType(leadRequest.getChannelType());
//	        commandHandler.saveLeadCustomer(leadCustomer);

			successResponse = CommonUtil.getSuccessResponse(Constants.AJ200, Constants.SAVE_SUCCESS,new LeadResponse("fname","987654328","abc@gmail.com",LocalDate.now()));

//	        apiStatusServiceImpl.saveApiStatus("LEAD_SEARCH_API", response.getStatusCode().value(), phoneNumber,
//	                response.getBody(), startTime, endTime);

			log.info("Customer data saved successfully");


		} catch (CustomException ex) {
			log.error(ex.getMessage());
			handler.handleException(ex, Constants.CREATE_CUSTOMER, "");
		} catch (HttpClientErrorException | HttpServerErrorException ex) {
			log.error("Exception in Create Customer API : " + ex.getResponseBodyAsString());
			handler.handleException(ex, Constants.CREATE_CUSTOMER, "");
		} catch (Exception ex) {
			log.error("Exception in Create Customer API :" + ex.getMessage());
			handler.handleException(new InternalException("AJ3101", ex), Constants.CREATE_CUSTOMER, "");
		}
		return ResponseEntity.status(HttpStatus.OK).body(successResponse);
	}

	@Override
	public ResponseEntity<SuccessResponse> createLeadWithConsent(String uniqueId, boolean isConsent) throws Exception {
		log.info("Starting createLeadWithConsent: {}", uniqueId);
		Timestamp startTime = CommonUtil.getCurrentTimestamp();
		SuccessResponse successResponse = null;
		ResponseEntity<LeadResponse> response = null;

		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<Object> entityHeader = new HttpEntity<>(uniqueId, headers);

			//LeadCustomer lead = queryHandler.getLeadCustomerByUniqueId(uniqueId);
			if (!isConsent) {
				log.info("Lead consent not found: " + uniqueId);
				throw new CustomException("AJ3002",Constants.CREATE_LEAD_WITH_CONSENT+"");
			}
			//lead.setConsent(isConsent);
// 	         response = restTemplate.exchange(createLeadWithConsentApiUrl, HttpMethod.POST, entityHeader, LeadResponse.class);
// 	         Timestamp endTime = CommonUtil.getCurrentTimestamp();
			//commandHandler.saveLeadCustomer(lead);
			successResponse = CommonUtil.getSuccessResponse(Constants.AJ200, Constants.SAVE_SUCCESS,new LeadResponse("fname","987654328","abc@gmail.com",LocalDate.now()));
		} catch (CustomException ex) {
			log.error(ex.getMessage());
			handler.handleException(ex, Constants.CREATE_LEAD_WITH_CONSENT, "");
		} catch (HttpClientErrorException | HttpServerErrorException ex) {
			log.error("Exception in createLeadWithConsent API : " + ex.getResponseBodyAsString());
			handler.handleException(ex, Constants.CREATE_LEAD_WITH_CONSENT, "");
		} catch (Exception ex) {
			log.error("Exception in createLeadWithConsent API :" + ex.getMessage());
			handler.handleException(new InternalException("AJ3102", ex), Constants.CREATE_LEAD_WITH_CONSENT, "");
		}
		return ResponseEntity.status(HttpStatus.OK).body(successResponse);

	}

	@Override
	public List<HelpIssueFilter> getIssueList() throws Exception {
		try {
			//return queryHandler.findAllHelpIssueFilter();

		} catch (HttpClientErrorException | HttpServerErrorException ex) {
			log.error("Exception in getIssueList API : " + ex.getResponseBodyAsString());
			handler.handleException(ex, Constants.GET_ISSUE_LIST, "");
		} catch (Exception ex) {
			log.error("Exception in getIssueList API :" + ex.getMessage());
			handler.handleException(new InternalException("AJ3103", ex), Constants.GET_ISSUE_LIST, "");
		}
<<<<<<< HEAD
		return null;
	}
=======
		//return null;
		return MockHelpIssuesList();
	}
	private List<HelpIssueFilter> MockHelpIssuesList() {
        List<HelpIssueFilter> mockIssues = new ArrayList<>();

        // Mock Issue 1
        HelpIssueFilter issue1 = new HelpIssueFilter();
        issue1.setIssueId(1);
        issue1.setIssueType("Technical Support");
        mockIssues.add(issue1);

        // Mock Issue 2
        HelpIssueFilter issue2 = new HelpIssueFilter();
        issue2.setIssueId(2);
        issue2.setIssueType("Billing Inquiry");
        mockIssues.add(issue2);

        // Mock Issue 3
        HelpIssueFilter issue3 = new HelpIssueFilter();
        issue3.setIssueId(3);
        issue3.setIssueType("Account Issue");
        mockIssues.add(issue3);

        return mockIssues;
    }
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26

	@Override
	public ResponseEntity<SuccessResponse> createIssue(HelpIssueFilter helpIssueFilter) throws Exception {
		SuccessResponse successResponse = null;
		try {
			//commandHandler.saveHelpIssueFilter(helpIssueFilter);
			successResponse = CommonUtil.getSuccessResponse(Constants.AJ200, Constants.CREATE_ISSUE,new HelpIssueFilter(1,"Issue1"));
		} catch (HttpClientErrorException | HttpServerErrorException ex) {
			log.error("Exception in createIssue API : " + ex.getResponseBodyAsString());
			handler.handleException(ex, Constants.CREATE_ISSUE, "");
		} catch (Exception ex) {
			log.error("Exception in createIssue API :" + ex.getMessage());
			handler.handleException(new InternalException("AJ3104", ex), Constants.CREATE_ISSUE, "");
		}
		return ResponseEntity.status(HttpStatus.OK).body(successResponse);
	}


	@Override
	public Object login(LoginDetails loginDetails) {

		log.info("Start of employeeValidate in Service");

		List<EmployeeValidateResponse> responses = new ArrayList<>();

		try {

			EmployeeValidateRequest validateRequest = createValidateRequest(loginDetails);
			EmployeeValidateResponse response = sendValidationRequest(validateRequest, loginDetails);
<<<<<<< HEAD
			
=======

>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26

		} catch (Exception ex) {
			log.error("An error occurred while processing employee validation for mobile number {}: {}",
					ex.getMessage());
		}

		return responses.isEmpty() ? null : responses.get(0);
	}

	private EmployeeValidateRequest createValidateRequest(LoginDetails loginDetails) {
		EmployeeValidateRequest validateRequest = new EmployeeValidateRequest();

		ObjRequest req = new ObjRequest();
		req.setMobileNo(loginDetails.getMobileNo() != null ? loginDetails.getMobileNo() : null);
		req.setAdid(loginDetails.getAdid() != null ? loginDetails.getAdid() : null);
		req.setEmail(loginDetails.getEmail() != null ? loginDetails.getEmail() : null);
		validateRequest.setObjRequest(req);

		return validateRequest;
	}

	public EmployeeValidateResponse sendValidationRequest(EmployeeValidateRequest validateRequest, LoginDetails loginDetails) {

		Date date = new Date();

		EmployeeValidateResponse response = null;
		String encoding = Base64.getEncoder().encodeToString((loginDetails.getEmail().trim() + ":" + loginDetails.getPassword().trim()).getBytes());
		log.info(encoding);

		String checkSumValue = createCheckSum(loginDetails, encoding);
		HttpHeaders headers = new HttpHeaders();
		headers.add(HttpHeaders.CONTENT_TYPE, "application/json");
		headers.add("DateTimeStamp", checksumUtils.getCurrentTimeStamp(date));
		headers.add("TokenID", loginDetails.getTokenID());
		headers.add(HttpHeaders.AUTHORIZATION, "Basic " + encoding);
		headers.add("Checksum", checkSumValue);
		HttpEntity<Object> entity = new HttpEntity<>(validateRequest, headers);
		log.info(entity.toString());
		response = restTemplate.postForObject(employeeValidateUrl, entity, EmployeeValidateResponse.class);
		return response;

	}

	private String createCheckSum(LoginDetails loginDetails, String encoding) {
		Date date = new Date();
		HttpHeaders headers = new HttpHeaders();
		headers.add(HttpHeaders.CONTENT_TYPE, "application/json");
		headers.add("DT_DateTimeStamp", checksumUtils.getCurrentTimeStamp(date));
		headers.add("TokenID", loginDetails.getTokenID());
		headers.add(HttpHeaders.AUTHORIZATION, "Basic " + encoding);
		headers.add("DT_ChecksumValue", loginDetails.getEmail());
		ChecksumRequest checksumRequest = new ChecksumRequest();
		HttpEntity<Object> httpEntity = new HttpEntity<>(checksumRequest, headers);
		log.info(httpEntity.toString());
		ChecksumResponse checksumResponse = restTemplate.postForObject(checksumUrl, httpEntity, ChecksumResponse.class);
		return checksumResponse.getChecksum();
	}

<<<<<<< HEAD
=======
	@Override
	public ResponseEntity<SuccessResponse> getTotalLeads(String loggedInUserId) throws Exception {
		SuccessResponse successResponse = null;
		try {
			//commandHandler.saveHelpIssueFilter(helpIssueFilter);
			successResponse = CommonUtil.getSuccessResponse(Constants.AJ200, Constants.CREATE_TOTAL_LEAD_COUNT,getMockLeadData());
		} catch (HttpClientErrorException | HttpServerErrorException ex) {
			log.error("Exception in createIssue API : " + ex.getResponseBodyAsString());
			handler.handleException(ex, Constants.CREATE_TOTAL_LEAD_COUNT, "");
		} catch (Exception ex) {
			log.error("Exception in createIssue API :" + ex.getMessage());
			handler.handleException(new InternalException("AJ3104", ex), Constants.CREATE_TOTAL_LEAD_COUNT, "");
		}
		return ResponseEntity.status(HttpStatus.OK).body(successResponse);

	}



    private TotalLeadsResponse getMockLeadData() {
        TotalLeadsResponse response = new TotalLeadsResponse();

        // Setting total lead count
        response.setTotalLeadCount(247);

        // Monthly totals for the last four months
        List<TotalLeadsResponse.MonthlyLeadCount> monthlyTotals = Arrays.asList(
            new TotalLeadsResponse.MonthlyLeadCount("2024-10", 60),
            new TotalLeadsResponse.MonthlyLeadCount("2024-09", 61),
            new TotalLeadsResponse.MonthlyLeadCount("2024-08", 63),
            new TotalLeadsResponse.MonthlyLeadCount("2024-07", 63)
        );
        response.setMonthlyTotals(monthlyTotals);

        // Product category counts
        List<TotalLeadsResponse.ProductCategoryCount> productCategoryCounts = Arrays.asList(
            new TotalLeadsResponse.ProductCategoryCount("HomeLoan", 50),
            new TotalLeadsResponse.ProductCategoryCount("PersonalLoan", 60),
            new TotalLeadsResponse.ProductCategoryCount("LifeInsurance", 45),
            new TotalLeadsResponse.ProductCategoryCount("HealthInsurance", 42),
            new TotalLeadsResponse.ProductCategoryCount("MutualFunds", 50)
        );
        response.setProductCategoryCounts(productCategoryCounts);

        // Status counts
        TotalLeadsResponse.StatusCount statusCounts = new TotalLeadsResponse.StatusCount();
        statusCounts.setOpen(100);
        statusCounts.setClosed(90);
        statusCounts.setPending(57);
        response.setStatusCounts(statusCounts);

        return response;
    }

	@Override
	public ResponseEntity<SuccessResponse> getCommunicationChannel() throws Exception {
		SuccessResponse successResponse = null;
		try {
			successResponse = CommonUtil.getSuccessResponse(Constants.AJ200, Constants.GET_COMMUNICATION_CHANEL,getCommunicationChanelList());
		} catch (HttpClientErrorException | HttpServerErrorException ex) {
			log.error("Exception in createIssue API : " + ex.getResponseBodyAsString());
			handler.handleException(ex, Constants.GET_COMMUNICATION_CHANEL, "");
		} catch (Exception ex) {
			log.error("Exception in createIssue API :" + ex.getMessage());
			handler.handleException(new InternalException("AJ3104", ex), Constants.GET_COMMUNICATION_CHANEL, "");
		}
		return ResponseEntity.status(HttpStatus.OK).body(successResponse);



	}
	private List<CommunicationChannel> getCommunicationChanelList(){
		List<CommunicationChannel> channels = Arrays.asList(
				new CommunicationChannel(1, "Message"),
				new CommunicationChannel(2, "Mail"),
				new CommunicationChannel(3, "WhatsApp")
		);

		return channels;
	}
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
}
