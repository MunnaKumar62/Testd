package com.abc.assistedJourney.entity;

import jakarta.persistence.Column;
import jakarta.persistence.GenerationType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.GeneratedValue;
import lombok.Data;

import java.sql.Timestamp;
import java.time.LocalDateTime;



@Entity
@Table(name = "t_assist_login_history")
@Data
public class UserLoginHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @Column(name = "time_stamp")
    private Timestamp timeStamp;

    @Column(name = "ip_address")
    private String ipAddress;

    @Column(name = "source_ip")
    private String sourceIP;

    @Column(name = "status")
    private boolean status;

    @Column(name = "os_type")
    private String osType;

    @Column(name = "location")
    private String location;
}


