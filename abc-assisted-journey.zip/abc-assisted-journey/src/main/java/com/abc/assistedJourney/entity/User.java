package com.abc.assistedJourney.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "t_assist_users")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username;
    private String email;
    private String password;
    private String name;
    private String employeeId;
    private String designation;
    private String department;

   @ManyToOne
   @JoinColumn(name = "role_id")
   private Role role;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<LoginHistory> loginHistory;


    @ElementCollection
    private List<String> salesEnablers;

    @ElementCollection
    private List<String> dskList;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    private List<LoginHistory> userLogs;

<<<<<<< HEAD
    public User(int i, String bobJohnson, String bobJohnson1) {
    }
=======
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
}
