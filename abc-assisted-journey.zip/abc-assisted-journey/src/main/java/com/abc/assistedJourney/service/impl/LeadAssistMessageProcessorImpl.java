package com.abc.assistedJourney.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.core.common.service.CommonMessageProcessor;

import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class LeadAssistMessageProcessorImpl implements CommonMessageProcessor{

	@Autowired
	ObjectMapper mapper;

	@Override
	public void processMessage(String messageType, String apiStatus) throws Exception {

		
	}

}
