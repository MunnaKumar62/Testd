package com.abc.assistedJourney.repository.command;

import com.abc.assistedJourney.entity.UserLoginHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import com.abc.assistedJourney.entity.RoleStatus;

public interface RoleStatusRepository  extends JpaRepository<RoleStatus, Long> {
}
