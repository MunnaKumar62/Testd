package com.abc.assistedJourney.model.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDTO {
    private int id;
    private String username;
    private String email;
    private String name;
    private String employeeId;
    private String designation;
    private String department;
   // private RoleDto role;
    private List<String> salesEnablers;
    private List<String> dskList;

    public UserDTO(int id, String email) {
        this.id = id;
        this.email = email;
    }
}
