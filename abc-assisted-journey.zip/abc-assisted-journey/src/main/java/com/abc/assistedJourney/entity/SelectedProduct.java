package com.abc.assistedJourney.entity;

import java.util.List;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "t_assist_selected_product")

public class SelectedProduct {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String productName;

    @ManyToMany(mappedBy = "selectedProducts")
    private List<UserDetails> userDetails;

}