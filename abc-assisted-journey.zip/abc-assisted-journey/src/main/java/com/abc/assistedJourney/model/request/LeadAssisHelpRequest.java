package com.abc.assistedJourney.model.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LeadAssisHelpRequest {

	private String raiseAnIssue;
	private String subject;
	private String description;
	//private List<MultipartFile> files;
	//private String filename;      // Name of the uploaded file
	//private String filepath;
}
