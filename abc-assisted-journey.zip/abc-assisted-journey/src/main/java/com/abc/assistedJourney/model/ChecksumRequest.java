package com.abc.assistedJourney.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ChecksumRequest {
	@JsonProperty("DataValue")
    private String dataValue;

    @JsonProperty("ClientIPAddress")
    private String clientIPAddress;

    @JsonProperty("DeviceID")
    private String deviceID;

    @JsonProperty("OS")
    private String os;

    @JsonProperty("IMEI")
    private String imei;

    @JsonProperty("UDP")
    private String udp;

    @JsonProperty("UDP1")
    private String udp1;

    @JsonProperty("UDP2")
    private String udp2;

    @JsonProperty("UDP3")
    private String udp3;

    @JsonProperty("UDP4")
    private String udp4;

    @JsonProperty("UDP5")
    private String udp5;
}
