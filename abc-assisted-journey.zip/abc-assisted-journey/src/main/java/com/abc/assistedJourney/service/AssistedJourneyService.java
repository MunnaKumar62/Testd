package com.abc.assistedJourney.service;

import com.abc.assistedJourney.entity.User;

public interface AssistedJourneyService {
	
	
}
