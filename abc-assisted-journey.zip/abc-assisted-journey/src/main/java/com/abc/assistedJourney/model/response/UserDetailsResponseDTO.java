package com.abc.assistedJourney.model.response;

import java.util.List;

import com.abc.assistedJourney.entity.OrganisationAgent;
import com.abc.assistedJourney.entity.OrganisationDirector;
import com.abc.assistedJourney.entity.ReportingManager;
import com.abc.assistedJourney.entity.SelectedProduct;
import com.abc.assistedJourney.entity.UserDetails;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDetailsResponseDTO {
    private UserDetails basicDetails;
    private ReportingManager reportingManagerDetails;
    private List<OrganisationDirector> organisationDirectors;
    private List<OrganisationAgent> organisationAgents;
    private List<SelectedProduct> selectedProducts;


}