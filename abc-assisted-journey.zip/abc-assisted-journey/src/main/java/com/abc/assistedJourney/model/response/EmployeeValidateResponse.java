package com.abc.assistedJourney.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class EmployeeValidateResponse {

    @JsonProperty("ReturnMessage")
    private String returnMessage;

    @JsonProperty("ReturnCode")
    private String returnCode;

    @JsonProperty("Active")
    private String active;

    @JsonProperty("EmployeeName")
    private String employeeName;

    @JsonProperty("EmpCodeEmpID")
    private String empCodeEmpID;

    @JsonProperty("EmploymentStatus")
    private String employmentStatus;

    @JsonProperty("CompanyNameEntity")
    private String companyNameEntity;

    @JsonProperty("Department")
    private String department;

    @JsonProperty("DepartmentID")
    private String departmentID;

    @JsonProperty("SubDepartment")
    private String subDepartment;

    @JsonProperty("FunctionName")
    private String functionName;

    @JsonProperty("SubFunctionName")
    private String subFunctionName;

    @JsonProperty("OfficialEmailId")
    private String officialEmailId;

    @JsonProperty("MobileNumber")
    private String mobileNumber;

    @JsonProperty("BusinessDesignation")
    private String businessDesignation;

    @JsonProperty("FunctionalDesignation")
    private String functionalDesignation;

    @JsonProperty("EmpCodeOfReportingManager")
    private String empCodeOfReportingManager;

    @JsonProperty("L1ManagerID")
    private String l1ManagerID;

    @JsonProperty("L1ManagerName")
    private String l1ManagerName;

    @JsonProperty("Country")
    private String country;

    @JsonProperty("Zone")
    private String zone;

    @JsonProperty("State")
    private String state;

    @JsonProperty("City")
    private String city;

    @JsonProperty("WorkLocation")
    private String workLocation;

    @JsonProperty("BranchCode")
    private String branchCode;

    @JsonProperty("JB")
    private String jb;

    @JsonProperty("CSE")
    private String cse;

    @JsonProperty("SecondaryPhoneNumber")
    private String secondaryPhoneNumber;

    @JsonProperty("UDF1")
    private String udf1;

    @JsonProperty("UDF2")
    private String udf2;

    @JsonProperty("PAN")
    private String pan;

    @JsonProperty("LastWorkingDay")
    private String lastWorkingDay;

    @JsonProperty("ReasonForSeparation")
    private String reasonForSeparation;

    @JsonProperty("DateOfJoining")
    private String dateOfJoining;
    
}