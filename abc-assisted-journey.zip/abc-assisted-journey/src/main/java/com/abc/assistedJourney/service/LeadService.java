package com.abc.assistedJourney.service;

import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;

import org.springframework.http.ResponseEntity;
import com.abc.assistedJourney.model.LoginDetails;

import com.abc.assistedJourney.common.model.SuccessResponse;
import com.abc.assistedJourney.entity.HelpIssueFilter;
import com.abc.assistedJourney.model.LeadRequest;
import com.abc.assistedJourney.model.LeadResponse;

public interface LeadService {
	
<<<<<<< HEAD
	public LeadResponse searchLead(String phoneNumber) throws Exception;

	public ResponseEntity<SuccessResponse> createCustomer(LeadRequest leadRequest) throws Exception;

	 public ResponseEntity<SuccessResponse> createLeadWithConsent(String uniqueId, boolean isConsent) throws Exception;

	 public List<HelpIssueFilter> getIssueList() throws Exception;

	public ResponseEntity<SuccessResponse> createIssue(HelpIssueFilter helpIssueFilter) throws Exception;
	public Object login(LoginDetails loginDetails);

=======
	LeadResponse searchLead(String phoneNumber) throws Exception;

	 ResponseEntity<SuccessResponse> createCustomer(LeadRequest leadRequest) throws Exception;

	  ResponseEntity<SuccessResponse> createLeadWithConsent(String uniqueId, boolean isConsent) throws Exception;

	 List<HelpIssueFilter> getIssueList() throws Exception;

	ResponseEntity<SuccessResponse> createIssue(HelpIssueFilter helpIssueFilter) throws Exception;
	Object login(LoginDetails loginDetails);

	ResponseEntity<SuccessResponse> getTotalLeads(String loggedInUserId) throws Exception;

	ResponseEntity<SuccessResponse> getCommunicationChannel() throws Exception;
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
}
