package com.abc.assistedJourney.model.response;

import com.abc.assistedJourney.entity.User;
<<<<<<< HEAD
=======
import com.abc.assistedJourney.model.request.UserDTO;
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.sql.Timestamp;
<<<<<<< HEAD
import java.time.LocalDateTime;

@Data
public class UserLoginHistoryResponse {

    @JsonProperty("user")
    private User user;

    @JsonProperty("sourceIp")
    private String status;

    @JsonProperty("osType")
    private String sourceIp;

    @JsonProperty("osType")
    private String osType;

    @JsonProperty("location")
    private String location;

    @JsonProperty("timestamp")
    private Timestamp timestamp;

    @JsonProperty("viewLogsLink")
=======

@Data
public class UserLoginHistoryResponse {
    private UserDTO user;
    private String status;
    private String sourceIp;
    private String osType;
    private String location;
    private Timestamp timestamp;
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
    private String viewLogsLink;
}
