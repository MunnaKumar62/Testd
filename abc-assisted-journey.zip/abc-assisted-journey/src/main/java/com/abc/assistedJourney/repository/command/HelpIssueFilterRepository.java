package com.abc.assistedJourney.repository.command;

import org.springframework.data.jpa.repository.JpaRepository;

import com.abc.assistedJourney.entity.HelpIssueFilter;

public interface HelpIssueFilterRepository extends JpaRepository<HelpIssueFilter, Integer>  {

}
