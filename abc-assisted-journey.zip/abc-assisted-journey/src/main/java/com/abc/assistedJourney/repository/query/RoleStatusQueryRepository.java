package com.abc.assistedJourney.repository.query;

public interface RoleStatusQueryRepository {

}
