package com.abc.assistedJourney.cache;

import com.common.redis.cache.RedisCacheProvider;
import com.common.redis.config.RedisConfig;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.lettuce.core.RedisException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

@Service
@Slf4j
public class GenericCacheService {

    @Autowired
    private RedisCacheProvider redisCacheProvider;

    @Autowired
    private RedisConfig redisConfig;

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private RedisUtil redisUtil;

    private static final long CACHE_TTL = 30;

    /**
     * Generic method to retrieve data from cache or database.
     *
     * @param cacheName The Redis cache name.
     * @param cacheParam The cache parameter (key).
     * @param typeReference The TypeReference for deserialization.
     * @param dbQuerySupplier The supplier for querying the database.
     * @param <T> The entity type (can be a list or a single entity).
     * @return List or entity of type T.
     */
    public <T> T getFromCacheOrDb(
            String cacheName,
            String cacheParam,
            TypeReference<T> typeReference,
            Supplier<T> dbQuerySupplier) {

        try {
            // Attempt to retrieve the data from the cache
            String cachedData = redisCacheProvider.getData(cacheName, cacheParam);

            if (cachedData != null) {
                try {
                    // Deserialize the JSON data into the required type (T)
                    T data = mapper.readValue(cachedData, typeReference);
                    log.info("Returning data from cache for {}", cacheParam);
                    return data;
                } catch (JsonProcessingException e) {
                    log.error("Error deserializing data from cache for {}: {}", cacheParam, e.getMessage());
                }
            }
        } catch (RedisException redisException) {
            // Log Redis connection errors
            log.error("Redis server is not available for {}: {}", cacheParam, redisException.getMessage());
        }

        // If cache is empty or Redis is unavailable, fetch data from the database
        T data = dbQuerySupplier.get();

        if (data == null) {
            throw new RuntimeException("No data found for: " + cacheParam);
        }

        try {
            // Serialize the data and add it to the cache
            String jsonData = mapper.writeValueAsString(data);
            redisCacheProvider.addData(cacheName, cacheParam, jsonData);
            redisConfig.redisTemplate().expire(cacheName, CACHE_TTL, TimeUnit.MINUTES);
        } catch (JsonProcessingException e) {
            log.error("Error serializing data for cache for {}: {}", cacheParam, e.getMessage());
        } catch (RedisException redisException) {
            log.error("Redis server is not available for {}: {}", cacheParam, redisException.getMessage());
        }
        return data;
    }

    public <T> void updateCache(String cacheName, String cacheParam, T newEntity, Class<T> entityType) throws JsonProcessingException, RedisException {
        try {
            retryCacheUpdate(cacheName, cacheParam, newEntity, entityType);
        } catch (RedisException e) {
            log.error("Failed to update Redis cache after {} attempts.", redisUtil.getMaxRetryAttempts());
        }
    }

    private <T> void retryCacheUpdate(String cacheName, String cacheParam, T newEntity, Class<T> entityType) throws RedisException, JsonProcessingException {
        for (int attempt = 1; attempt <= redisUtil.getMaxRetryAttempts(); attempt++) {
            try {
                String cachedData = redisCacheProvider.getData(cacheName, cacheParam);
                if (cachedData != null && !cachedData.isEmpty()) {
                    List<T> entityList = updateEntityList(cachedData, newEntity, entityType);
                    updateCacheWithNewEntityList(cacheName, cacheParam, entityList);
                    log.info("Successfully updated {} cache on attempt {}", cacheName, attempt);
                    return;
                }
            } catch (RedisException redisException) {
                log.error("Redis update failed on attempt {} of {}: {}", attempt, redisUtil.getMaxRetryAttempts(), redisException.getMessage());
                try {
                    if (attempt == redisUtil.getMaxRetryAttempts()) {
                        redisCacheProvider.deleteData(cacheName, cacheParam);
                    }
                } catch (RedisException rdException) {
                    log.error("Failed to delete Redis cache after {} attempts.", redisUtil.getMaxRetryAttempts());
                }
                waitBeforeRetry(); // Wait before retrying
            }
        }
    }

    private <T> List<T> updateEntityList(String cachedData, T newEntity, Class<T> entityType) throws JsonProcessingException {
        List<T> entityList = mapper.readValue(cachedData, mapper.getTypeFactory().constructCollectionType(List.class, entityType));
        boolean entityUpdated = entityList.stream()
                .filter(entity -> Objects.equals(getEntityId(entity), getEntityId(newEntity))) // Compare IDs (assumes all entities have getId())
                .findFirst()
                .map(existingEntity -> {
                    int index = entityList.indexOf(existingEntity);
                    entityList.set(index, newEntity); // Update existing entity
                    return true;
                })
                .orElse(false);

        if (!entityUpdated) {
            entityList.add(newEntity); // Add new entity if not found
        }
        return entityList;
    }

    private <T> void updateCacheWithNewEntityList(String cacheName, String cacheParam, List<T> entityList) throws JsonProcessingException {
        String jsonData = mapper.writeValueAsString(entityList);
        redisCacheProvider.updateData(cacheName, cacheParam, jsonData);
    }

    private void waitBeforeRetry() {
        try {
            Thread.sleep(redisUtil.getRetryDelayMs());
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
            log.error("Thread was interrupted: {}", ie.getMessage());
        }
    }

    // Helper method to extract ID (this can be customized based on your entities)
    private <T> Object getEntityId(T entity) {
        try {
            return entity.getClass().getMethod("getId").invoke(entity); // Assuming all entities have a getId() method
        } catch (Exception e) {
            throw new RuntimeException("Entity does not have getId() method", e);
        }
    }

}
