package com.abc.assistedJourney.entity;
 
import java.time.LocalDateTime;
 
import com.google.cloud.Timestamp;
 
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.Data;
 
@Data
@Entity
@Table(name = "t_leadassist_api_status")
public class LeadAssistAPIStatusEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "leadassist_apistatus_id")
	private long leadAssistApiStatusId;
 
	@Column(name = "apiname" , nullable = false)
	private String apiName;
 
	@Column(name = "status", nullable = false)
	private String status;
 
	@Column(name = "httpstatuscode")
	private int httpStatusCode;
 
	@Column(name = "user_id")
	private Long userId;
 
    @Column(name = "lead_id")
	private Integer leadId;
 
	@Column(name = "request")
	private String request;
 
	@Column(name = "response")
    private String response;
	
	@Column(name = "api_start_time")
	private Timestamp apiStartTime;
	
	@Column(name = "api_end_time")
	private Timestamp apiEndTime;
	
	@Column(name = "created_date")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime createdDate;
	
	@Column(name = "created_by", length = 45)
	private String createdBy;
	
	@Column(name = "modified_by", length = 45)
	private String modifiedBy;
	
	@Column(name = "modified_date")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime modifiedDate;
	
	@Column(name = "active")
	private boolean active;
 
}
