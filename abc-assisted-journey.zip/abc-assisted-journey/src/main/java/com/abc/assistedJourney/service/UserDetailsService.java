package com.abc.assistedJourney.service;

import com.abc.assistedJourney.model.response.UserDetailsResponseDTO;

public interface UserDetailsService {

    UserDetailsResponseDTO getUserDetailsByUniqueId(String uniqueId, String constitutionType);
}