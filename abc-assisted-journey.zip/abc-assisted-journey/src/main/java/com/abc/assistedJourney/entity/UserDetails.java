package com.abc.assistedJourney.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "t_assist_user_details")
public class UserDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String employeeId;
    private String name;
    private String role;
    private String email;
    private String address;
    private String gender;
    private LocalDate dateOfBirth;
    private String zone;
    private String branch;
    private LocalDate dateOfJoining;
    private String mobile;
    private String dsaCode;
    private String constitutionType;
    private String onboardedBy;
    private LocalDateTime onboardedDate;
    private String currentAddress;
    private String permanentAddress;
    private String nameOfOrganisation;
    private String organisationType;
    private String officeAddress;
    private LocalDate dateOfIncorporation;

    // Relationships
    @OneToOne(mappedBy = "userDetails", cascade = CascadeType.ALL)
    private ReportingManager reportingManager;

    @OneToMany(mappedBy = "userDetails", cascade = CascadeType.ALL)
    private List<OrganisationDirector> organisationDirectors;

    @OneToMany(mappedBy = "userDetails", cascade = CascadeType.ALL)
    private List<OrganisationAgent> organisationAgents;

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(
            name = "user_selected_products",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "product_id"))
    private List<SelectedProduct> selectedProducts;
}