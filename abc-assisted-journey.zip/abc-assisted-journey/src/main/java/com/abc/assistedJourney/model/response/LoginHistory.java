package com.abc.assistedJourney.model.response;

public class LoginHistory {
}
