package com.abc.assistedJourney.controller;

<<<<<<< HEAD

=======
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
import com.abc.assistedJourney.common.constants.Constants;
import com.abc.assistedJourney.common.model.SuccessResponse;
import com.abc.assistedJourney.common.util.CommonUtil;
import com.abc.assistedJourney.entity.Role;
import com.abc.assistedJourney.entity.RoleStatus;
import com.abc.assistedJourney.service.RoleService;
import com.abc.assistedJourney.service.RoleStatusService;
<<<<<<< HEAD
=======
import lombok.extern.log4j.Log4j2;
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

<<<<<<< HEAD

import java.util.List;


@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping(Constants.API + Constants.VERSION_ONE)
public class RoleController {
=======
import java.util.List;

@Log4j2
@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("/api/v1/leadAssist/user") 
public class RoleController {

>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
    @Autowired
    private RoleService roleService;

    @Autowired
    private RoleStatusService roleStatusService;

<<<<<<< HEAD
    public ResponseEntity<SuccessResponse> getAllRoles() {
        try {
            List<Role> roles = roleService.getAllRoles();
            SuccessResponse successResponse = CommonUtil.getSuccessResponse(
                    "AJ2005", Constants.RETRIEVED_SUCCESS, roles);
            return new ResponseEntity<>(successResponse, HttpStatus.OK);
        } catch (Exception e) {
            // Log the exception (optional)
            SuccessResponse errorResponse = CommonUtil.getErrorResponse(
                    "AJ2006", Constants.RETRIEVAL_FAILED, null); // Assuming you have a method for error responses
=======
    @GetMapping("/roles")
    public ResponseEntity<SuccessResponse> getAllRoles() {
        log.info("Attempting to fetch all roles...");
        try {
            List<Role> roles = roleService.getAllRoles();

            if (roles == null || roles.isEmpty()) {
                log.warn("No roles found in the database.");
                return new ResponseEntity<>(
                        CommonUtil.getSuccessResponse("AJ2005", "No roles found.", null),
                        HttpStatus.NOT_FOUND
                );
            }

            SuccessResponse successResponse = CommonUtil.getSuccessResponse(
                    "AJ2005", Constants.RETRIEVED_SUCCESS, roles);
            return new ResponseEntity<>(successResponse, HttpStatus.OK);

        } catch (Exception e) {
            log.error("Error fetching roles: {}", e.getMessage(), e);
            SuccessResponse errorResponse = CommonUtil.getErrorResponse(
                    "AJ2006", Constants.RETRIEVAL_FAILED, null);
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
            return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

<<<<<<< HEAD
    @GetMapping
    public ResponseEntity<SuccessResponse> getAllRoleStatuses() {
=======
    @GetMapping("/status")
    public ResponseEntity<SuccessResponse> getAllRoleStatuses() {
        log.info("Fetching all role statuses...");
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
        List<RoleStatus> roleStatuses = roleStatusService.getAllRoleStatuses();
        SuccessResponse successResponse = CommonUtil.getSuccessResponse(
                "AJ2005", Constants.RETRIEVED_SUCCESS, roleStatuses);
        return new ResponseEntity<>(successResponse, HttpStatus.OK);
    }

<<<<<<< HEAD

    @PostMapping
    public ResponseEntity<SuccessResponse> createRoleStatus(@RequestBody RoleStatus roleStatus) {
=======
    @PostMapping("/status")
    public ResponseEntity<SuccessResponse> createRoleStatus(@RequestBody RoleStatus roleStatus) {
        log.info("Creating role status: {}", roleStatus);
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
        RoleStatus createdRoleStatus = roleStatusService.createRoleStatus(roleStatus);
        SuccessResponse successResponse = CommonUtil.getSuccessResponse(
                "AJ2006", Constants.CREATED_SUCCESS, createdRoleStatus);
        return new ResponseEntity<>(successResponse, HttpStatus.CREATED);
    }
<<<<<<< HEAD

=======
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
}
