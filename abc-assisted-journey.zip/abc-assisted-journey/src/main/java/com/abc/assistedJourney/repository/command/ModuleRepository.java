package com.abc.assistedJourney.repository.command;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.abc.assistedJourney.entity.LeadModule;

import java.util.Optional;

@Repository
public interface ModuleRepository extends JpaRepository<LeadModule, Long> {
    Optional<LeadModule> findByName(String name); // Using 'name' for clarity
}

