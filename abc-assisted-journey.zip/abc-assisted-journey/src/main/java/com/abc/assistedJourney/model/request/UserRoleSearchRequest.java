package com.abc.assistedJourney.model.request;

import lombok.Data;

@Data
public class UserRoleSearchRequest {
    private Long loggedInUserId;
    private String employeeId;

}

