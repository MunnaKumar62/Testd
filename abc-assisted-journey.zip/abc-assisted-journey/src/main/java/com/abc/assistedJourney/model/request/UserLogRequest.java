package com.abc.assistedJourney.model.request;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class UserLogRequest {
    private String loggedInUserId;  // Logged in user ID
    private String selectedUserId;   // Selected user ID
    private LocalDateTime startDate; // Start date for the range
    private LocalDateTime endDate;   // End date for the range
}
