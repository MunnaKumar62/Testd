package com.abc.assistedJourney.common.constants;


import java.net.URI;

/**
 * 
 */
public interface Constants {

	public static final String API = "/api";

	public static final String VERSION_ONE = "/v1";

	public static final String LEAD_ASSIST = "/leadAssist";

	public static final String API_STATUS = "/api-status";

	public static final String ASSISTED_JOURNEY = "/assisted-journey";
	public static final String USER = "/user";
	public static final String LOGS  ="/logs";
	public static final String SUCCESS = "success";

	public static final String FAILURE = "Failure";

	public static final String AJ200 = "AJ200";

	public static final String RETRIEVED_SUCCESS = "Retrieved Successfully";
	public static final String CREATED_SUCCESS = "Created Successfully";
	public static final String RETRIEVAL_FAILED = "Retrieved Failed";

	public static final String SAVE_SUCCESS = "Saved Successfully";

	public static final String REMOVE_SUCCESS = "Removed Successfully";

    public static final String ERROR = "error";
	// For Sonar Fix
	public static final String LOG_TEXT_AROUND = "logAround=>";
	public static final String CONSENT_DATETIME_FORMAT = "dd/MM/yyyy HH:mm:ss";
	public static final String CONSENT_DATETIME_FORMAT_HYPHEN = "dd-MM-yyyy HH:mm:ss a";

	public static final String ERROR_TYPE_BUSINESS = "BE";
	public static final String ERROR_TYPE_TECHNICAL = "TE";
	public static final String SEARCH_LEAD = "SEARCH_LEAD";
	public static final String SAVE_OR_UPDATE_LEAD = "SAVE_OR_UPDATE_LEAD";
	public static final String EMPTY_FILE = "EMPTY_FILE";
	public static final String USER_PROFILE_RESPONSEDATA_EMPTY = "USER_PROFILE_RESPONSEDATA_EMPTY";
	public static final String CREATE_CUSTOMER = "CREATE_CUSTOMER";
	public static final String CREATE_LEAD_WITH_CONSENT = "CREATE_LEAD_WITH_CONSENT";
	public static final String GET_ISSUE_LIST = "GET_ISSUE_LIST";
	public static final String CREATE_ISSUE = "CREATE_ISSUE";
<<<<<<< HEAD
=======
	public static final String CREATE_TOTAL_LEAD_COUNT="CREATE_TOTAL_LEAD_COUNT";
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
	String LOG_IN_HISTORY = "loginHistory";
	String GET_USER_LOGIN_HISTORY_URL = "https://mockapi.example.com/getUserHistory";
	public static final String GET_USER_LOGS = "GET_USER_LOGS";
	public static final String GET_PROFILE = "GET_PROFILE";
	public static final String UPLOAD_IMAGE = "UPLOAD_IMAGE";
	public static final String LEAD_ASSIS_HELP = "LEAD_ASSIS_HELP";
	public static final String REMOVE_PROFILE_IMAGE = "REMOVE_PROFILE_IMAGE";
<<<<<<< HEAD

=======
	String GET_COMMUNICATION_CHANEL =" GET_COMMUNICATION_CHANEL";
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
}
