package com.abc.assistedJourney.model.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDetailsResponse {
    private String employeeName;
    private String designation;
    private String emailId;
    private String department;
    private List<String> salesEnablers;
    private List<String> dskList;

}
