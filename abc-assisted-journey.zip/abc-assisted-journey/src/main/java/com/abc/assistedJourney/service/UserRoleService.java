package com.abc.assistedJourney.service;

import com.abc.assistedJourney.entity.Role;
import com.abc.assistedJourney.model.request.RoleSubmitRequest;
import com.abc.assistedJourney.model.response.UserDetailsResponse;
import com.abc.assistedJourney.model.response.UserRoleResponse;

import java.util.Set;

public interface UserRoleService {
    // Update User Roles
    boolean updateUserRole(Long uniqueId, Long loggedInUserId, Role updatedRoles);

    // Search for User Role and details
    UserDetailsResponse searchUserRole(Long loggedInUserId, String employeeId);

    // Submit the Selected Role
    boolean submitUserRole(RoleSubmitRequest request);
}