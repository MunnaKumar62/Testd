package com.abc.assistedJourney.service;

<<<<<<< HEAD
import org.springframework.data.domain.Pageable;
import com.abc.assistedJourney.model.request.UserLogRequestDTO;
import com.abc.assistedJourney.model.response.UserLogResponseDTO;
import java.util.List;

public interface UserLogService {

    List<UserLogResponseDTO> getUserLogs(UserLogRequestDTO request, Pageable pageable) throws Exception;
=======
import java.time.LocalDateTime;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.abc.assistedJourney.model.request.LogRequestDTO;
import com.abc.assistedJourney.model.response.LogResponseDTO;

public interface UserLogService {
    Page<LogResponseDTO> getUserLogs(String userId, LogRequestDTO requestDTO, Pageable pageable);
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
}