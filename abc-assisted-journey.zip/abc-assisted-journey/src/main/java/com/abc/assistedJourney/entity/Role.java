package com.abc.assistedJourney.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "t_assist_role")
@Data
@NoArgsConstructor
public class Role {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String roleName;

    private String reportsTo;

    private String createdTimeStamp;

    private String status;

    @ManyToMany
    @JoinTable(
            name = "role_permissions",
            joinColumns = @JoinColumn(name = "role_id"),
            inverseJoinColumns = @JoinColumn(name = "permission_id")
    )
    private Set<Permission> permissions = new HashSet<>();

    // A role can have multiple modules
    @OneToMany(mappedBy = "role", cascade = CascadeType.ALL)
    private Set<Module> modules = new HashSet<>();

    // A role can have multiple services
    @OneToMany(mappedBy = "role", cascade = CascadeType.ALL)
    private Set<Services> services = new HashSet<>();
}
