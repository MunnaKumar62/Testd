package com.abc.assistedJourney.model.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TotalLeadsResponse {

    private int totalLeadCount;
    private List<MonthlyLeadCount> monthlyTotals;
    private List<ProductCategoryCount> productCategoryCounts;
    private StatusCount statusCounts;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class MonthlyLeadCount {
        private String month;
        private int count;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class ProductCategoryCount {
        private String category;
        private int count;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class StatusCount {
        private int open;
        private int closed;
        private int pending;
    }
}
