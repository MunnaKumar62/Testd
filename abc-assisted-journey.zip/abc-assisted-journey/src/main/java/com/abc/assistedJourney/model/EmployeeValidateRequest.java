package com.abc.assistedJourney.model;


import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class EmployeeValidateRequest {

	@JsonProperty("ObjRequest")
	public ObjRequest objRequest;
	

}
