package com.abc.assistedJourney.model.request;

import com.abc.assistedJourney.entity.User;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Data
public class RoleSubmitRequest {
    private Long loggedInUserId;
    private String employeeName;
    private String designation;
    private String emailId;
    private String department;
    private String selectedRole;
    private Map<String, Boolean> salesEnablersAccess;
    private Map<String, Boolean> dskListAccess;


}
