package com.abc.assistedJourney.repository.command;

import com.abc.assistedJourney.entity.Role;
import com.abc.assistedJourney.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRoleRepository extends JpaRepository<Role, Long> {
    Optional<Role> findByRoleName(String roleName);
}