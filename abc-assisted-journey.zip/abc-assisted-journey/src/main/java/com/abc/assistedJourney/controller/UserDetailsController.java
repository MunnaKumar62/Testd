package com.abc.assistedJourney.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import com.abc.assistedJourney.common.constants.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.abc.assistedJourney.entity.OrganisationDirector;
import com.abc.assistedJourney.entity.ReportingManager;
import com.abc.assistedJourney.entity.UserDetails;
import com.abc.assistedJourney.model.response.UserDetailsResponseDTO;
import com.abc.assistedJourney.service.UserDetailsService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping(Constants.API + Constants.VERSION_ONE+Constants.LEAD_ASSIST)
public class UserDetailsController {
    @Autowired
    private UserDetailsService userDetailsService;

    @GetMapping("/user/{uniqueId}")
    public ResponseEntity<UserDetailsResponseDTO> getUserDetails(@PathVariable String uniqueId,
                                                                 @RequestParam(required = false) String constitutionType) {
        UserDetailsResponseDTO responseDTO;

        // Attempt to find user details using uniqueId as Employee ID
        responseDTO = userDetailsService.getUserDetailsByUniqueId(uniqueId, null);

        if (responseDTO.getBasicDetails() == null) {
            // If not found by Employee ID, check for DSA Code with Constitution Type
            if (constitutionType != null) {
                responseDTO = userDetailsService.getUserDetailsByUniqueId(uniqueId, constitutionType);
            } else {
                return ResponseEntity.badRequest().body(null); // Constitution type is required
            }
        }

        return ResponseEntity.ok(responseDTO);
    }
}