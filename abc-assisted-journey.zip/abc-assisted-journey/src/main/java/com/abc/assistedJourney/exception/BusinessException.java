/**
 * Author: srividhya.s
 * Date: Jul 04, 2024
 * ModifiedBy : srividhya.s
 * 
 */
package com.abc.assistedJourney.exception;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BusinessException extends RuntimeException {
	private static final long serialVersionUID = 4087930070289795747L;

	private String errorCode;
	private String errorMessage;
	private Integer code = 206;
	private String reason;
	private Exception sourceException;

	public BusinessException() {
		super();
	}

	public BusinessException(Throwable cause) {
		super();
	}

	public BusinessException(String errorCode) {
		super();
		this.errorCode = errorCode;
	}
	public BusinessException(int code,String errorCode) {
		super();
		this.errorCode = errorCode;
	}
	
	public BusinessException(String errorCode, Exception ex) {
		super();
		this.errorCode = errorCode;
		this.sourceException = ex;
	}
	
	public BusinessException(String errorCode, String errorMessage) {
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}
	
	public BusinessException(String errorCode, String errorMessage, Integer code, String reason) {
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.code = code;
		this.reason = reason;
	}
}
