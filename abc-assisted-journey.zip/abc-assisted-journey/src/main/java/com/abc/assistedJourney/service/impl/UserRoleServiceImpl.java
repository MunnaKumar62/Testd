package com.abc.assistedJourney.service.impl;


import com.abc.assistedJourney.entity.*;
import com.abc.assistedJourney.model.request.RoleSubmitRequest;
import com.abc.assistedJourney.model.response.UserDetailsResponse;
import com.abc.assistedJourney.model.response.UserRoleResponse;
import com.abc.assistedJourney.repository.command.ModuleRepository;
import com.abc.assistedJourney.repository.command.PermissionRepository;
import com.abc.assistedJourney.repository.command.RoleRepository;
import com.abc.assistedJourney.repository.command.UserRepository;
import com.abc.assistedJourney.repository.query.UserRoleQueryRepo;
import com.abc.assistedJourney.service.UserRoleService;
import com.abc.core.common.exception.CommonExceptionHandler;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.abc.assistedJourney.handler.CommandHandler;
import com.abc.assistedJourney.handler.QueryHandler;

import java.util.*;
import java.util.stream.Collectors;


@Service
@Log4j2
public class UserRoleServiceImpl implements UserRoleService {


    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private PermissionRepository permissionRepository;

    @Autowired
    private ModuleRepository moduleRepository;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    QueryHandler queryHandler;

    @Autowired
    private CommonExceptionHandler handler;

    @Autowired
    CommandHandler commandHandler;

    @Autowired
    private UserRoleQueryRepo userRoleQueryRepo;




    @Override
    public boolean updateUserRole(Long uniqueId, Long loggedInUserId, Role updatedRole) {
        Optional<User> user = userRepository.findById(uniqueId);

        if (user.isPresent()) {
            User targetUser = user.get();
            targetUser.setRole(updatedRole); // Assuming roles is a Set<String>
            userRepository.save(targetUser);
            return true;
        }
        return false;
    }

    @Override
    public UserDetailsResponse searchUserRole(Long loggedInUserId, String employeeId) {
        return mockedValueUserRole();
        /* commented for since we used Mock Values here
        Optional<User> userOpt = userRepository.findByEmployeeId(employeeId);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            UserDetailsResponse response = new UserDetailsResponse();
            response.setEmployeeName(user.getName());
            response.setDesignation(user.getDesignation());
            response.setEmailId(user.getEmail());
            response.setDepartment(user.getDepartment());
            response.setSalesEnablers(user.getSalesEnablers()); // Assuming it's a list
            response.setDskList(user.getDskList()); // Assuming it's a list
            return response;
        }
        return null;

         */
    }
    private UserDetailsResponse mockedValueUserRole() {
        UserDetailsResponse userDetailsResponse = new UserDetailsResponse();

        // Mock data for testing
        userDetailsResponse.setEmployeeName("John Doe");
        userDetailsResponse.setDesignation("Software Engineer");
        userDetailsResponse.setEmailId("john.doe@example.com");
        userDetailsResponse.setDepartment("IT");

        // Mock sales enablers list
        List<String> salesEnablers = new ArrayList<>();
        salesEnablers.add("Loan Calculator");
        salesEnablers.add("Investment Calculator");
        userDetailsResponse.setSalesEnablers(salesEnablers);

        // Mock DSK list
        List<String> dskList = new ArrayList<>();
        dskList.add("Investments");
        dskList.add("Loans");
        dskList.add("Insurance");
        userDetailsResponse.setDskList(dskList);

        // Return the mock response
        return userDetailsResponse;
    }

    @Override
    public boolean submitUserRole(RoleSubmitRequest request) {
        Optional<User> userOpt = userRepository.findByUsername(request.getEmailId());
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            Optional<Role> roleOpt = roleRepository.findByRoleName(request.getSelectedRole());
            if (roleOpt.isPresent()) {
                user.setRole(roleOpt.get());
            }
            user.setSalesEnablers((List<String>) request.getSalesEnablersAccess());
            user.setDskList((List<String>) request.getDskListAccess());
            userRepository.save(user);
            return true;
        }
        return false;
    }

}

