package com.abc.assistedJourney.service;

import com.abc.assistedJourney.entity.Role;

import java.util.List;

public interface RoleService {

    List<Role> getAllRoles();
}
