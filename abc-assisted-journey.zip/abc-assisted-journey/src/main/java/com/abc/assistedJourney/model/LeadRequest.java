package com.abc.assistedJourney.model;

import java.time.LocalDate;

import lombok.Data;

@Data
public class LeadRequest {
	
	private String fullName;
    private String mobileNumber;
    private String emailId;
    private LocalDate dob;
    private String channelType;


}
