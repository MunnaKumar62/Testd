package com.abc.assistedJourney.controller;

import com.abc.assistedJourney.entity.User;
import com.abc.assistedJourney.model.CreateUserRequest;
import com.abc.assistedJourney.model.response.UserDetailsResponse;
import com.abc.assistedJourney.model.response.UserLoginHistoryResponse;
import com.abc.assistedJourney.service.UserService;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.abc.assistedJourney.common.constants.Constants;
import com.abc.assistedJourney.common.model.SuccessResponse;
import com.abc.assistedJourney.common.util.CommonUtil;
import com.abc.assistedJourney.model.request.LeadAssisHelpRequest;
import com.abc.assistedJourney.model.response.UserResponse;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping(Constants.API + Constants.VERSION_ONE)
public class UserController {
    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;

    @PostMapping("/create")
    public ResponseEntity<User> createUser(@RequestBody CreateUserRequest request) {
        User createdUser = userService.createUserWithRoleAndPermissions(
                request.getUsername(),
                request.getEmail(),
                request.getPassword(),
                request.getRoleName(),
                request.getModulePermissions()
        );

        return ResponseEntity.status(HttpStatus.CREATED).body(createdUser);
    }

    @GetMapping("leadAssist/user/loginHistory")
    public ResponseEntity<SuccessResponse> getUserHistoryFromApi(@RequestParam String userId) {
        try {
            List<UserLoginHistoryResponse> responseList = userService.getUserHistoryResponse(userId);
            SuccessResponse successResponse = CommonUtil.getSuccessResponse(
                    "AJ2005", Constants.RETRIEVED_SUCCESS, responseList);
            return new ResponseEntity<>(successResponse, HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error retrieving user login history for user ID {}: {}", userId, e.getMessage(), e);
            SuccessResponse errorResponse = CommonUtil.getErrorResponse(
                    "AJ2006", Constants.RETRIEVAL_FAILED, null);
            return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }





    @GetMapping("/leadAssist/profile/{userID}")
    public ResponseEntity<SuccessResponse> getProfile(@PathVariable String userID) throws Exception {
    	UserResponse profile = userService.getProfile(userID);
        SuccessResponse successResponse = CommonUtil.getSuccessResponse("AJ2000", Constants.RETRIEVED_SUCCESS,
        		profile);
        return new ResponseEntity(successResponse, HttpStatus.OK);
    }

    @PostMapping("/leadAssist/profileUpload")
    public ResponseEntity<SuccessResponse> uploadProfileImage(@RequestParam("file") MultipartFile file) throws Exception {
	 String uploadImage = userService.uploadImage(file);
        SuccessResponse successResponse = CommonUtil.getSuccessResponse("AJ2001", Constants.SAVE_SUCCESS,
        		uploadImage);
        return new ResponseEntity(successResponse, HttpStatus.OK);
    }

    @DeleteMapping("/leadAssist/removeProfileImage/{id}")
    public ResponseEntity<SuccessResponse> removeProfileImage(@PathVariable Long id ) throws Exception {
	 String removedProfileImage = userService.removeProfileImage(id);
        SuccessResponse successResponse = CommonUtil.getSuccessResponse("AJ2003", Constants.REMOVE_SUCCESS,
        		removedProfileImage);
        return new ResponseEntity(successResponse, HttpStatus.OK);
    }

	@PostMapping("/leadAssist/help")
	public ResponseEntity<SuccessResponse> leadAssisHelp(@RequestBody LeadAssisHelpRequest leadAssisHelp) throws Exception {
		String saved = userService.leadAssisHelp(leadAssisHelp);
		SuccessResponse successResponse = CommonUtil.getSuccessResponse("AJ2001", Constants.SAVE_SUCCESS, saved);
		return new ResponseEntity(successResponse, HttpStatus.OK);
	}

    @GetMapping("/leadAssist/getAllUser")
    public List<UserDetailsResponse> getAllUsers(@RequestParam("loggedinUserId") String id) {
        return userService.getAllUsers(id);
    }
}
