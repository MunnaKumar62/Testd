package com.abc.assistedJourney.handler;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import com.abc.assistedJourney.entity.*;
import com.abc.assistedJourney.repository.command.RoleRepository;
import com.abc.assistedJourney.repository.command.RoleStatusRepository;
import com.abc.assistedJourney.repository.query.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;


@Service
public class QueryHandler {
	@Autowired
	UserLoginHistoryQueryRepo userLoginHistoryQueryRepo;

	@Autowired
	RoleRepository roleRepository;

	@Autowired
	private RoleStatusRepository roleStatusRepository;

	@Autowired
	LeadQueryRepository leadQueryRepository;

	@Autowired
	LeadCustomerQueryRepository leadCustomerQueryRepository;

	@Autowired
	UserRoleQueryRepo userRoleQueryRepo;

	@Autowired
	HelpIssueFilterQueryRepository helpIssueFilterQueryRepository;

	public List<UserLoginHistory> getLoginHistoryByUser(User user) {
		return userLoginHistoryQueryRepo.findByUser(user);
	}

	public List<Role> getAllRole() {
		return roleRepository.findAll();
	}

	public List<RoleStatus> getAllRoleStatuses() {
		return roleStatusRepository.findAll();
	}

	public Lead getLeadByMobileNumber(String mobileNumber) {
		return leadQueryRepository.findByMobileNumber(mobileNumber);
	}

	public LeadCustomer getLeadCustomerByUniqueId(String uniqueId) {
		return leadCustomerQueryRepository.findByUniqueId(uniqueId);
	}

	public List<HelpIssueFilter> findAllHelpIssueFilter() {
		return helpIssueFilterQueryRepository.findAll();
	}

	public List<UserRole> findAllUserRole() {
		return userRoleQueryRepo.findAll();
	}

}