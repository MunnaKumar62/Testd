package com.abc.assistedJourney.service.impl;

import com.abc.assistedJourney.entity.RoleStatus;
import com.abc.assistedJourney.handler.CommandHandler;
import com.abc.assistedJourney.handler.QueryHandler;
import com.abc.assistedJourney.service.RoleStatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class RoleStatusServiceImpl implements RoleStatusService {

    @Autowired
    QueryHandler queryHandler;

    @Autowired
    CommandHandler commandHandler;

    @Override
    public List<RoleStatus> getAllRoleStatuses() {
        return getAllRoleStatusByMock();
        //return queryHandler.getAllRoleStatuses();
    }

    @Override
    public RoleStatus createRoleStatus(RoleStatus roleStatus) {
        return commandHandler.createRoleStatus(roleStatus);
    }

    private   List<RoleStatus>  getAllRoleStatusByMock (){
        // Mocking three role statuses for testing purposes
        List<RoleStatus> roleStatuses = new ArrayList<>();

        // First status: Active
        RoleStatus activeStatus = new RoleStatus();
        activeStatus.setId(1L);
        activeStatus.setStatusName("Active");

        // Second status: In-progress
        RoleStatus inProgressStatus = new RoleStatus();
        inProgressStatus.setId(2L);
        inProgressStatus.setStatusName("In-progress");

        // Third status: Closed
        RoleStatus closedStatus = new RoleStatus();
        closedStatus.setId(3L);
        closedStatus.setStatusName("Closed");

        // Adding the mocked statuses to the list
        roleStatuses.add(activeStatus);
        roleStatuses.add(inProgressStatus);
        roleStatuses.add(closedStatus);

        return roleStatuses;
    }
}

