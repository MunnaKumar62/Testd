package com.abc.assistedJourney.repository.command;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.abc.assistedJourney.entity.CustomerDetails;

@Repository
public interface customerDetailRepository extends JpaRepository<CustomerDetails, Long>{

}
