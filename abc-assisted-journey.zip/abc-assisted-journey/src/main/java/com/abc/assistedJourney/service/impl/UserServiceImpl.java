package com.abc.assistedJourney.service.impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.abc.assistedJourney.model.response.UserDetailsResponse;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.abc.assistedJourney.common.constants.Constants;
import com.abc.assistedJourney.entity.LeadAssisHelpEntity;
import com.abc.assistedJourney.entity.LeadModule;
import com.abc.assistedJourney.entity.Permission;
import com.abc.assistedJourney.entity.Role;
import com.abc.assistedJourney.entity.User;
import com.abc.assistedJourney.exception.CustomException;
import com.abc.assistedJourney.handler.CommandHandler;
import com.abc.assistedJourney.handler.QueryHandler;
import com.abc.assistedJourney.repository.command.ImageRepository;
import com.abc.assistedJourney.common.util.CommonUtil;
import com.abc.assistedJourney.entity.*;
import com.abc.assistedJourney.exception.InternalException;
import com.abc.assistedJourney.model.response.UserLoginHistoryResponse;
import com.abc.assistedJourney.repository.command.ModuleRepository;
import com.abc.assistedJourney.repository.command.PermissionRepository;
import com.abc.assistedJourney.repository.command.RoleRepository;
import com.abc.assistedJourney.repository.command.UserRepository;
import com.abc.assistedJourney.repository.query.UserRepositoryQuery;
import com.abc.assistedJourney.model.request.LeadAssisHelpRequest;
<<<<<<< HEAD
=======
import com.abc.assistedJourney.model.request.UserDTO;
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
import com.abc.assistedJourney.model.response.UserResponse;
import com.abc.assistedJourney.service.UserService;
import com.abc.core.common.exception.CommonExceptionHandler;
import lombok.extern.log4j.Log4j2;

import java.sql.Timestamp;
import java.util.*;

@Service
@Log4j2
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private PermissionRepository permissionRepository;

    @Autowired
    private ModuleRepository moduleRepository;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private CommonExceptionHandler handler;

	@Autowired
	QueryHandler queryHandler;

	@Autowired
	CommandHandler commandHandler;

//	@Value("${upload.directory}")
	private String uploadDir;

	@Autowired
	ImageRepository imageRepository;

	@Autowired
	private UserRepositoryQuery userRepositoryQuery;

	private static final String EXTERNAL_API_URL = "https://api.example.com/user/{userID}";

    @Override
    public List<UserLoginHistoryResponse> getUserHistoryResponse(String userId) throws Exception {
        log.info("Starting user login history for : {}", userId);
        ResponseEntity<UserLoginHistoryResponse> response = null;
        Timestamp startTime = CommonUtil.getCurrentTimestamp();

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<Object> entityHeader = new HttpEntity<>(userId, headers);

           // response = restTemplate.exchange(Constants.GET_USER_LOGIN_HISTORY_URL, HttpMethod.POST, entityHeader, UserLoginHistoryResponse.class);
           // if (response == null || response.getBody() == null) {
            //    throw new CustomException("AL2000", Constants.LOG_IN_HISTORY + "");
            //}
          /*  UserLoginHistoryResponse userLoginHistoryResponse = response.getBody();
            saveOrUpdateUserLoginResponse(userLoginHistoryResponse);
            Timestamp endTime = CommonUtil.getCurrentTimestamp();
//	        apiStatusServiceImpl.saveApiStatus("USER_LOGIN_HISTORY_API", response.getStatusCode().value(), userId,
//	                response.getBody(), startTime, endTime);
            log.info("Lead search completed successfully for phone number: {}", userId);
            return userLoginHistoryResponse;*/
            return mockedLoginHistory();
        } catch (CustomException ex) {
            log.error(ex.getMessage());
            handler.handleException(ex, Constants.LOG_IN_HISTORY, "");
        } catch (HttpClientErrorException | HttpServerErrorException ex) {
            log.error("Exception in Lead search API : " + ex.getResponseBodyAsString());
            handler.handleException(ex, Constants.LOG_IN_HISTORY, "");
        } catch (Exception ex) {
            log.error("Exception in Lead search API :" + ex.getMessage());
            handler.handleException(new InternalException("AL2100",  ex.getMessage()), Constants.LOG_IN_HISTORY, "");
        }
        return null;
    }
    private List<UserLoginHistoryResponse> mockedLoginHistory (){
        List<UserLoginHistoryResponse> mockLoginHistory = new ArrayList<>();

        // Mock login history record 1
        UserLoginHistoryResponse history1 = new UserLoginHistoryResponse();
<<<<<<< HEAD
        history1.setUser(new User(3,"JohnDoe", "John Doe"));  // Assuming User has a constructor
=======
        history1.setUser(new UserDTO(1,"testMail"));  // Assuming User has a constructor
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
        history1.setStatus("Success");
        history1.setSourceIp("192.168.1.1");
        history1.setOsType("Windows 10");
        history1.setLocation("New York, USA");
        history1.setTimestamp(CommonUtil.getCurrentTimestamp());
        history1.setViewLogsLink("http://example.com/logs/1");

        // Mock login history record 2
        UserLoginHistoryResponse history2 = new UserLoginHistoryResponse();
<<<<<<< HEAD
        history2.setUser(new User(2,"JaneSmith", "Jane Smith"));
=======
        history2.setUser(new UserDTO(2,"testMail"));
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
        history2.setStatus("Failed");
        history2.setSourceIp("192.168.2.5");
        history2.setOsType("Mac OS");
        history2.setLocation("Los Angeles, USA");
        history2.setTimestamp(CommonUtil.getCurrentTimestamp());
        history2.setViewLogsLink("http://example.com/logs/2");

        // Mock login history record 3
        UserLoginHistoryResponse history3 = new UserLoginHistoryResponse();
<<<<<<< HEAD
        history3.setUser(new User(1,"BobJohnson", "Bob Johnson"));
=======
        history3.setUser(new UserDTO(3,"test3"));
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
        history3.setStatus("Success");
        history3.setSourceIp("10.0.0.10");
        history3.setOsType("Ubuntu Linux");
        history3.setLocation("Chicago, USA");
        history3.setTimestamp(CommonUtil.getCurrentTimestamp());
        history3.setViewLogsLink("http://example.com/logs/3");

        // Add mock data to list
        mockLoginHistory.add(history1);
        mockLoginHistory.add(history2);
        mockLoginHistory.add(history3);

        // Return mock data as response
        return mockLoginHistory;
    }

    private void saveOrUpdateUserLoginResponse(UserLoginHistoryResponse userLoginHistoryResponse) {
<<<<<<< HEAD
        User user = userLoginHistoryResponse.getUser();

=======
        UserDTO userRespose = userLoginHistoryResponse.getUser();
        User user = new User();
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
        // Fetch the login history for the user
        List<UserLoginHistory> existingLoginHistoryList = queryHandler.getLoginHistoryByUser(user);

        // Assuming we're working with the first record if it exists
        UserLoginHistory existingLoginHistory = existingLoginHistoryList.isEmpty() ? null : existingLoginHistoryList.get(0);

        if (existingLoginHistory == null) {
            UserLoginHistory newLoginHistory = new UserLoginHistory();
<<<<<<< HEAD
            newLoginHistory.setUser(userLoginHistoryResponse.getUser());
=======
         //   newLoginHistory.setUser(userLoginHistoryResponse.getUser());
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
            newLoginHistory.setIpAddress(userLoginHistoryResponse.getSourceIp());
            newLoginHistory.setSourceIP(userLoginHistoryResponse.getSourceIp());
            newLoginHistory.setOsType(userLoginHistoryResponse.getOsType());
            newLoginHistory.setLocation(userLoginHistoryResponse.getLocation());
            newLoginHistory.setTimeStamp(userLoginHistoryResponse.getTimestamp());
            newLoginHistory.setStatus(true);  // Assuming status is active for new entries

            // Save the new login history record
            commandHandler.save(newLoginHistory);
            log.info("User login history saved for user: {}", userLoginHistoryResponse.getUser().getId());

        } else {
            // Update existing history
            existingLoginHistory.setIpAddress(userLoginHistoryResponse.getSourceIp());
            existingLoginHistory.setSourceIP(userLoginHistoryResponse.getSourceIp());
            existingLoginHistory.setOsType(userLoginHistoryResponse.getOsType());
            existingLoginHistory.setLocation(userLoginHistoryResponse.getLocation());
            existingLoginHistory.setTimeStamp(userLoginHistoryResponse.getTimestamp());
            existingLoginHistory.setStatus(true);  // Assuming status is active

            // Save the updated record
            commandHandler.save(existingLoginHistory);
            log.info("User login history updated for user: {}", userLoginHistoryResponse.getUser().getId());
        }
    }


    @Override
	// Create a user and assign role with permissions
	public User createUserWithRoleAndPermissions(String username, String email, String password, String roleName,
			Map<String, List<String>> modulePermissions) {
		// Find or create the role
		Role role = roleRepository.findByRoleName(roleName).orElse(new Role());
		role.setRoleName(roleName);

        // Assign permissions to the role based on modules and permission types
        Set<Permission> permissions = new HashSet<>();
        for (Map.Entry<String, List<String>> entry : modulePermissions.entrySet()) {
            String name = entry.getKey();
            List<String> permissionTypes = entry.getValue();

            // Find or create the module
            LeadModule module = moduleRepository.findByName(name).orElse(new LeadModule());
            module.setName(name);
            moduleRepository.save(module);

            // Create permissions for each type (READ, WRITE, DELETE) and link to the module
            for (String permissionType : permissionTypes) {
                Permission permission = new Permission();
                permission.setPermissionName(permissionType);
                permission.setModule(module);
                permissionRepository.save(permission);
                permissions.add(permission);
            }
        }

        // Set permissions to role
        role.setPermissions(permissions);
        roleRepository.save(role);

        // Create a new user
        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(password);  // Normally you would encode the password using BCrypt
        user.setRole(role);

        // Save the user
        return userRepository.save(user);
    }

    @Override
    public UserResponse getProfile(String userID) throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Object> httpEntity = new HttpEntity<>(headers);
        UserResponse userResponse = new UserResponse();
        User user = new User();
        ResponseEntity<User> responseData = null;
        try {
            // responseData = restTemplate.exchange(EXTERNAL_API_URL, HttpMethod.GET,
            // httpEntity, User.class, userID);
            // if (responseData != null) {
            if (responseData == null) {
                // User responseData = responseData.getBody();
                /*
                 * User responseBody = responseData.getBody(); user.setId(responseBody.getId());
                 * user.setEmail(responseBody.getEmail());
                 * user.setPassword(responseBody.getPassword());
                 * user.setUsername(responseBody.getUsername());
                 * user.setRole(responseBody.getRole());
                 *
                 * commandHandler.saveUser(user); BeanUtils.copyProperties(responseData,
                 * userResponse);
                 *
                 */
                user.setId(1l);
                user.setEmail("ram.a.kumar@gmail.com");
                user.setPassword("ram@123");
                user.setUsername("ramkumar123");
                user.setRole(null);
                System.out.println("user :: " + user);
                userResponse.setEmployeeId("emp123");
                userResponse.setMobileNumber("1234567890");
                userResponse.setDepartment("Developer");
                userResponse.setManager("ram.a.kumar");
                userResponse.setPhoneNumber("044-12345");
                userResponse.setDivision("North-south");
                userResponse.setDateOfBirth(LocalDate.now());
                System.out.println("userResponse :: " + userResponse);
                BeanUtils.copyProperties(user, userResponse);
            } else {
                // throw new CustomException("AJ2002", Constants.USER_PROFILE_RESPONSEDATA_EMPTY
                // + responseData);
                throw new CustomException("AJ2002",
                        Constants.USER_PROFILE_RESPONSEDATA_EMPTY + ", userResponse:: " + userResponse);
            }
            return userResponse;
        } catch (CustomException ex) {
            log.error("Error in getProfile API", ex.getMessage());
            handler.handleException(ex, Constants.GET_PROFILE, "");
        } catch (HttpClientErrorException | HttpServerErrorException ex) {
            log.error("Error in getProfile API : " + ex.getResponseBodyAsString());
            handler.handleException(ex, Constants.GET_PROFILE, "");
        } catch (Exception ex) {
            log.error("Error in getProfile API :" + ex.getMessage());
            handler.handleException(new com.abc.core.common.exception.InternalException("AJ1000", ex), Constants.GET_PROFILE, "");
            log.error("End of getProfile api ");
        }
        return userResponse;
    }

    @Override
    public String uploadImage(MultipartFile file) throws Exception {
        if (file.isEmpty()) {
            throw new CustomException("AJ2002", Constants.EMPTY_FILE + file);
        }
        try {
            /*
             * File directory = new File(uploadDir); if (!directory.exists()) {
             * directory.mkdirs(); }
             *
             * Path path = Paths.get(uploadDir + file.getOriginalFilename());
             * Files.write(path, file.getBytes());
             *
             * UploadImage image = new UploadImage();
             * image.setFilename(file.getOriginalFilename());
             * image.setFilepath(path.toString());
             * commandHandler.uploadImage(image);
             */
            return "File uploaded successfully: " + file.getOriginalFilename();
        } catch (CustomException ex) {
            log.error("Error in uploadImage API", ex.getMessage());
            handler.handleException(ex, Constants.UPLOAD_IMAGE, "");
        } catch (HttpClientErrorException | HttpServerErrorException ex) {
            log.error("Error in uploadImage API : " + ex.getResponseBodyAsString());
            handler.handleException(ex, Constants.UPLOAD_IMAGE, "");
        } catch (Exception ex) {
            log.error("Error in uploadImage API :" + ex.getMessage());
            handler.handleException(new com.abc.core.common.exception.InternalException("AJ1001", ex), Constants.UPLOAD_IMAGE, "");
            log.info("End of uploadImage api ");
        }
        return "File uploaded successfully: " + file.getOriginalFilename();
    }

    @Override
    public String removeProfileImage(Long id) throws Exception {
        String response = "profile image removed successfully";
        try {
            //commandHandler.removeProfileImage(id);
        } catch (CustomException ex) {
            log.error("Error in removeProfileImage API", ex.getMessage());
            handler.handleException(ex, Constants.REMOVE_PROFILE_IMAGE, "");
        } catch (HttpClientErrorException | HttpServerErrorException ex) {
            log.error("Error in removeProfileImage API : " + ex.getResponseBodyAsString());
            handler.handleException(ex, Constants.REMOVE_PROFILE_IMAGE, "");
        } catch (Exception ex) {
            log.error("Error in removeProfileImage API :" + ex.getMessage());
            handler.handleException(new com.abc.core.common.exception.InternalException("AJ2004", ex), Constants.REMOVE_PROFILE_IMAGE, "");
            log.info("End of removeProfileImage api ");
        }
        return response;
    }

    @Override
    public String leadAssisHelp(LeadAssisHelpRequest leadAssisHelp) throws Exception {
        LeadAssisHelpEntity entity = new LeadAssisHelpEntity();
        List<MultipartFile> filesList = new ArrayList<>();
        String response = "saved successfully";
        try {
            entity.setRaiseAnIssue("RaiseAnIssue");
            entity.setDescription("description");
            entity.setSubject("help ticket creation ");
            entity.setFilename("demo data");
            //commandHandler.saveLeadAssisHelp(entity);
        } catch (CustomException ex) {
            log.error("Error in leadAssisHelp API", ex.getMessage());
            handler.handleException(ex, Constants.LEAD_ASSIS_HELP, "");
        } catch (HttpClientErrorException | HttpServerErrorException ex) {
            log.error("Error in leadAssisHelp API : " + ex.getResponseBodyAsString());
            handler.handleException(ex, Constants.LEAD_ASSIS_HELP, "");
        } catch (Exception ex) {
            log.error("Error in leadAssisHelp API :" + ex.getMessage());
            handler.handleException(new com.abc.core.common.exception.InternalException("AJ1002", ex), Constants.LEAD_ASSIS_HELP, "");
            log.info("End of leadAssisHelp api ");
        }
        return response;
    }

    public List<UserDetailsResponse> getAllUsers(String id) {
        // Step 1: Call external API
        //UserDetailsResponse[] externalUsers = restTemplate.getForObject(EXTERNAL_API_URL, UserDetailsResponse[].class);
        // Step 2: Initialize a list to hold the updated user details
        List<UserDetailsResponse> userList = new ArrayList<>();
        List<UserDetailsResponse> externalUsers = Arrays.asList(new UserDetailsResponse("Jyoti","Sales","employee","Sales Manager", Collections.singletonList("active"), Collections.singletonList("123")),
                new UserDetailsResponse("Alice", "Marketing", "employee", "Marketing Specialist", Collections.singletonList("inactive"), Collections.singletonList("124")));
        // Step 3: Process API response and insert/update in DB
     /*   if (externalUsers != null) {
            for (UserDetailsResponse user : externalUsers) {
                // Check if the user exists in DB, if not insert or update
                //UserDetailsEntity existingUser = userDetailsRepository.findByEmployeeId(user.getEmployeeId());
                UserDetailsResponse existingUser = new UserDetailsResponse();
                if (existingUser != null) {
                    // Update logic
                    existingUser.setName(user.getName());
                    existingUser.setDepartment(user.getDepartment());
                    existingUser.setRole(user.getRole());
                    existingUser.setReportingManager(user.getReportingManager());
                    existingUser.setStatus(user.getStatus());
                    // userDetailsRepository.save(existingUser);
                }*/
//                else {
//                    // Insert new user
//                    UserDetailsEntity newUser = new UserDetailsEntity();
//                    newUser.setName(user.getName());
//                    newUser.setDepartment(user.getDepartment());
//                    newUser.setRole(user.getRole());
//                    newUser.setReportingManager(user.getReportingManager());
//                    newUser.setStatus(user.getStatus());
//                    newUser.setEmployeeId(user.getEmployeeId());
//                   // userDetailsRepository.save(newUser);
//                }
                // Add the user to the list that will be returned in the response
         //       userList.add(user);
       //     }
     //   }
        // Step 4: Return the list of user details
        return externalUsers;
    }
}
