package com.abc.assistedJourney.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "t_assist_reporting_manager")
public class ReportingManager {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String sales;
    private String division;
    private String reportingTo;
    private String reportingManagerRole;
    private String reportingManagerName;
    private String emailId;
    private String contactNumber;
    private String department;
    private String branch;

    @OneToOne
    @JoinColumn(name = "user_id")
    private UserDetails userDetails;
}