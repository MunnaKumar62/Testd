package com.abc.assistedJourney.model;
import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LeadResponse {
	
	private String fullName;
	private String mobileNumber;
	private String emailId;
	private LocalDate dob;

}
