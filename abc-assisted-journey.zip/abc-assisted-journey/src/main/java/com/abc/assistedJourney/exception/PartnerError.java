package com.abc.assistedJourney.exception;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class PartnerError {

	@JsonProperty("code")
	private Integer code;
	
	@JsonProperty("reason")
	private String reason;
	
	@JsonProperty("message")
	private String message; 

}