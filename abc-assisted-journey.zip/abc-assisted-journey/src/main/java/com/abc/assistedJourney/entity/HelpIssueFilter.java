package com.abc.assistedJourney.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
<<<<<<< HEAD
=======
import lombok.NoArgsConstructor;
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26

@Entity
@Table(name="t_assist_issue_type")
@Data
@AllArgsConstructor
<<<<<<< HEAD
=======
@NoArgsConstructor
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
public class HelpIssueFilter {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int issueId;
	private String issueType;	

}
