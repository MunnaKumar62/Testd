package com.abc.assistedJourney.repository.command;
 
import org.springframework.data.jpa.repository.JpaRepository;
 
import com.abc.assistedJourney.entity.LeadAssistAPIStatusEntity;
 
public interface AssistedJourneyApiStatusRepository extends JpaRepository<LeadAssistAPIStatusEntity, Long> {
 
}
 