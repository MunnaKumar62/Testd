package com.abc.assistedJourney.entity;

import jakarta.persistence.Column;
import jakarta.persistence.GenerationType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.GeneratedValue;
import lombok.Data;

import java.time.LocalDateTime;


@Data
@Entity
@Table(name = "t_assist_login_history")
public class LoginHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id",nullable = false)
    private User user;

    @Column(name = "login_time")
    private LocalDateTime loginTime;

    @Column(name = "logout_time")
    private LocalDateTime logoutTime;

    private String ipAddress;

    @Column(name = "client_ip")
    private String clientIp;

    private String module;

    @Column(name ="session_id")
    private String sessionId;

    @Column(name ="time_stamp")
    private LocalDateTime timestamp;
}

