package com.abc.assistedJourney.model;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class CreateUserRequest {

    private String username;
    private String email;
    private String password;
    private String roleName;
    private Map<String, List<String>> modulePermissions;
}