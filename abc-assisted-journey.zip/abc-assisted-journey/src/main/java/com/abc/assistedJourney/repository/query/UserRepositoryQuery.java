package com.abc.assistedJourney.repository.query;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.abc.assistedJourney.entity.Journey;
import com.abc.assistedJourney.entity.User;

@Repository
public interface UserRepositoryQuery extends JpaRepository<User, Long>{

	
	//User getProfile(String userID);
	
	@Query("FROM User u WHERE u.id = :userID")
    User getProfile(@Param("userID") String userID);

}
