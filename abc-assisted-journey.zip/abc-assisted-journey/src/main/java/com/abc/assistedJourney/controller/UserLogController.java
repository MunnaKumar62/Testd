<<<<<<< HEAD

package com.abc.assistedJourney.controller;

import com.abc.assistedJourney.common.constants.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
=======
package com.abc.assistedJourney.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

<<<<<<< HEAD
import com.abc.assistedJourney.model.request.UserLogRequestDTO;
import com.abc.assistedJourney.model.response.UserLogResponseDTO;
import com.abc.assistedJourney.service.UserLogService;

import java.util.List;

=======
import com.abc.assistedJourney.common.constants.Constants;
import com.abc.assistedJourney.model.request.LogRequestDTO;
import com.abc.assistedJourney.model.response.LogResponseDTO;
import com.abc.assistedJourney.service.UserLogService;

>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping(Constants.API + Constants.VERSION_ONE+Constants.LEAD_ASSIST+Constants.USER+Constants.LOGS)
public class UserLogController {

    @Autowired
    private UserLogService userLogService;

<<<<<<< HEAD
    @PostMapping
    public ResponseEntity<List<UserLogResponseDTO>> getUserLogs(
            @RequestBody UserLogRequestDTO request,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) throws Exception {

        Pageable pageable = PageRequest.of(page, size);
        List<UserLogResponseDTO> logs = userLogService.getUserLogs(request, pageable);
=======
    @PostMapping("/{userId}")
    public ResponseEntity<Page<LogResponseDTO>> getUserLogs(
            @PathVariable String userId,
            @RequestBody LogRequestDTO requestDTO,
            Pageable pageable) {
        Page<LogResponseDTO> logs = userLogService.getUserLogs(userId, requestDTO, pageable);
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
        return ResponseEntity.ok(logs);
    }
}
