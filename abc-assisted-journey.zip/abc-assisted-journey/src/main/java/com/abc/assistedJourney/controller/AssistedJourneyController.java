package com.abc.assistedJourney.controller;


import com.abc.assistedJourney.common.constants.Constants;
import com.abc.assistedJourney.common.model.SuccessResponse;
import com.abc.assistedJourney.common.util.CommonUtil;
import com.abc.assistedJourney.entity.HelpIssueFilter;
import com.abc.assistedJourney.model.LeadRequest;
import com.abc.assistedJourney.model.LeadResponse;
import com.abc.assistedJourney.service.LeadService;

import com.abc.assistedJourney.model.LoginDetails;
import com.abc.assistedJourney.service.LeadService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.log4j.Log4j2;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Log4j2
@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping(Constants.API + Constants.VERSION_ONE)
@Tag(name = "API's for Assisted Journey")
public class AssistedJourneyController {

	@Autowired
    private LeadService leadService;

	@PostMapping("leadAssist/login")
	public ResponseEntity<Object> login(@RequestBody LoginDetails loginDetails) {
		Object response = "Login Successful!";
//		Object response = leadService.login(loginDetails);

		return new ResponseEntity<>(response, HttpStatus.OK);

	}

    @GetMapping("/leadAssist/search")
    public ResponseEntity<SuccessResponse> searchLeads(@RequestParam String mobileNumber) throws Exception {
        LeadResponse leadResponse = leadService.searchLead(mobileNumber);
        SuccessResponse successResponse = CommonUtil.getSuccessResponse(Constants.AJ200, Constants.RETRIEVED_SUCCESS,
        		leadResponse);
        return new ResponseEntity<>(successResponse, HttpStatus.OK);
    }

    @PostMapping("/leadAssist/create")
    public ResponseEntity<SuccessResponse> createLead(@RequestBody LeadRequest leadRequest) throws Exception {
       return leadService.createCustomer(leadRequest);
    }



    @GetMapping("/create/consent")
    public ResponseEntity<SuccessResponse> createLeadConsent(@RequestParam String uniqueId,@RequestParam boolean isConsent) throws Exception {
           return leadService.createLeadWithConsent(uniqueId,isConsent);
    }

    @GetMapping("/leadAssist/issues/filter")
    public ResponseEntity<SuccessResponse> getIssueList() throws Exception {
        List<HelpIssueFilter> helpIssueFilterList= leadService.getIssueList();
        SuccessResponse successResponse = CommonUtil.getSuccessResponse(Constants.AJ200, Constants.RETRIEVED_SUCCESS,
        		helpIssueFilterList);
        return new ResponseEntity<>(successResponse, HttpStatus.OK);
    }

    @PostMapping("/leadAssist/issues/filter/create")
    public ResponseEntity<SuccessResponse> createIssue(@RequestBody HelpIssueFilter helpIssueFilter) throws Exception {
       return leadService.createIssue(helpIssueFilter);
    }

<<<<<<< HEAD
=======
    @PostMapping("/leadAssist/getTotalLeads")
    public ResponseEntity<SuccessResponse> getTotalLeads(@RequestParam String loggedInUserId) throws Exception {
        return leadService.getTotalLeads(loggedInUserId);
    }

    @GetMapping("/leadAssist/communicationChannel")
    public ResponseEntity<SuccessResponse> getCommunicationChannel() throws Exception {
        return leadService.getCommunicationChannel();
    }

>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
}