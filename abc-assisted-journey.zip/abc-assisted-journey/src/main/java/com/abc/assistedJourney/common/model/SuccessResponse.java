package com.abc.assistedJourney.common.model;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SuccessResponse {

	private LocalDateTime timestamp;
	private String status;
	private String code;
	private String message;
	private Object data;

}
