package com.abc.assistedJourney.model.response;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class LogResponseDTO {
    private LocalDateTime timestamp;
    private String userId;
    private String clientIp;
    private String module;
    private String sessionId;
}
