package com.abc.assistedJourney.model.response;

import lombok.NoArgsConstructor;

import lombok.AllArgsConstructor;
import lombok.Data;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class CommunicationChannel {

    private int id;
    private String channelName;
}