package com.abc.assistedJourney.service;

import com.abc.assistedJourney.entity.Role;
import com.abc.assistedJourney.entity.RoleStatus;

import java.util.List;

public interface RoleStatusService {
    List<RoleStatus> getAllRoleStatuses();
    RoleStatus createRoleStatus(RoleStatus roleStatus);
}

