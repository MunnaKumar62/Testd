package com.abc.assistedJourney.controller;


import com.abc.assistedJourney.model.request.RoleSubmitRequest;
import com.abc.assistedJourney.model.request.UpdateUserRoleRequest;
import com.abc.assistedJourney.model.request.UserRoleSearchRequest;
import com.abc.assistedJourney.model.response.UserDetailsResponse;
import com.abc.assistedJourney.service.UserRoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/leadAssist/user")
public class UserRoleController {

    @Autowired
    private UserRoleService userRoleService;

    // Edit User Role
<<<<<<< HEAD
    @PutMapping("/update/{uniqueId}")
=======
    @PostMapping("/update/{uniqueId}")
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
    public ResponseEntity<String> updateUserRole(@PathVariable("uniqueId") Long uniqueId,
                                                 @RequestBody UpdateUserRoleRequest request) {
       // boolean isUpdated = userRoleService.updateUserRole(uniqueId, request.getLoggedInUserId(),
             //   request.getUpdatedRole());
        boolean isUpdated = true;
        if (isUpdated) {
            return ResponseEntity.ok("User roles updated successfully");
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to update user roles");
        }
    }

    // Assign Role - Search
    @PostMapping("/role/search")
    public ResponseEntity<UserDetailsResponse> searchUserRole(@RequestBody UserRoleSearchRequest request) {
        UserDetailsResponse userDetails = userRoleService.searchUserRole(request.getLoggedInUserId(),
                request.getEmployeeId());
        if (userDetails != null) {
            return ResponseEntity.ok(userDetails);
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

    // Selected Role on Submit
    @PostMapping("/role/submit")
    public ResponseEntity<String> submitUserRole(@RequestBody RoleSubmitRequest request) {
       // boolean isSubmitted = userRoleService.submitUserRole(request);
        boolean isSubmitted = true;
        if (isSubmitted) {
            return ResponseEntity.ok("User role submitted successfully");
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to submit user role");
        }
    }
}
