package com.abc.assistedJourney.service.impl;
import java.time.LocalDateTime;
 
import com.google.cloud.Timestamp;
 
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
 
import com.abc.assistedJourney.common.constants.Constants;
import com.abc.assistedJourney.entity.Lead;
import com.abc.assistedJourney.entity.LeadAssistAPIStatusEntity;
import com.abc.assistedJourney.handler.CommandHandler;
import com.abc.assistedJourney.model.LeadResponse;
import com.abc.assistedJourney.repository.command.AssistedJourneyApiStatusRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
 
 
import lombok.extern.log4j.Log4j2;
 
@Service
@Log4j2
public class ApiStatusServiceImpl {
	@Autowired
	ObjectMapper objectMapper;
	
	@Autowired
	CommandHandler commandHandler;
	
	@Autowired
	private AssistedJourneyApiStatusRepository apiStatusRepository;
 
	public void saveApiStatus(String apiName, int statusCode, Object request, String response,
			Timestamp apiStarttime, Timestamp apiEndTime, Long userId)  {
		log.info("Satrt saveApiStatus method");
		LeadAssistAPIStatusEntity apiEntity = new LeadAssistAPIStatusEntity();
		try {
			apiEntity.setApiName(apiName);
            apiEntity.setStatus(statusCode == 200 || statusCode == 202 ? "SUCCESS" : "FAILURE");
            apiEntity.setHttpStatusCode(statusCode);
            apiEntity.setUserId(userId);
            //apiEntity.setLeadId(leadId);
            apiEntity.setRequest(objectMapper.writeValueAsString(request));
            apiEntity.setResponse(response);
            apiEntity.setApiStartTime(apiStarttime);
            apiEntity.setApiEndTime(apiEndTime);
            apiEntity.setActive(true);
            apiEntity.setCreatedBy("User");
            apiEntity.setModifiedBy("User");
            apiEntity.setCreatedDate(LocalDateTime.now());
            apiEntity.setModifiedDate(LocalDateTime.now());
 
			
            commandHandler.save(apiEntity);
		} catch (Exception ex) {
			log.error("Error saving API : " + ex.getMessage(), ex);
			apiEntity.setResponse(null);
			commandHandler.save(apiEntity);
		}
		log.info("End saveApiStatus method");
	}
	
	public void saveApiStatusForInternal(String apiName, int statusCode, Object request, Object response,
			Timestamp apiStarttime, Timestamp apiEndTime, Long userId)  {
		log.info("Satrt saveApiStatus method");
		try {
			LeadAssistAPIStatusEntity apiEntity = new LeadAssistAPIStatusEntity();
			apiEntity.setApiName(apiName);
	        apiEntity.setStatus(statusCode == 200 ? Constants.SUCCESS : Constants.FAILURE);
	        apiEntity.setHttpStatusCode(statusCode);
	        apiEntity.setUserId(userId); // Updated to set userId
	        apiEntity.setRequest(objectMapper.writeValueAsString(request));
	        apiEntity.setResponse(objectMapper.writeValueAsString(response));
	        apiEntity.setApiStartTime(apiStarttime);
	        apiEntity.setApiEndTime(apiEndTime);
	        apiEntity.setActive(true);
	        apiEntity.setCreatedBy("User");
	        apiEntity.setModifiedBy("User");
	        apiEntity.setCreatedDate(LocalDateTime.now());
	        apiEntity.setModifiedDate(LocalDateTime.now());
 
			commandHandler.save(apiEntity);
		} catch (DataAccessException ex) {
			log.error("Error saving API : " + ex.getMessage(), ex);
		} catch (Exception ex) {
			log.error("Error saving API status : " + ex.getMessage(), ex);
		}
		log.info("End saveApiStatus method");
	}
 
	public void saveApiFailureStatus(String apiName, Long userId, String status, int code, String request,
			Timestamp apiStarttime, Timestamp apiEndTime) throws Exception{
		log.info("Satrt saveApiFailureStatus method");
		try {
			LeadAssistAPIStatusEntity apiEntity = new LeadAssistAPIStatusEntity();
			apiEntity.setResponse(null);
			apiEntity.setApiName(apiName);
			apiEntity.setStatus(status);
			apiEntity.setHttpStatusCode(code);
			apiEntity.setUserId(userId);
			apiEntity.setRequest(request);
			apiEntity.setApiStartTime(apiStarttime);
			apiEntity.setApiEndTime(apiEndTime);
			apiEntity.setActive(true);
			apiEntity.setCreatedBy("User");
			apiEntity.setModifiedBy("User");
			apiEntity.setCreatedDate(LocalDateTime.now());
			apiEntity.setModifiedDate(LocalDateTime.now());
 
			commandHandler.save(apiEntity);
		} catch (DataAccessException ex) {
			log.error("Error saving API status: " + ex.getMessage(), ex);
		} catch (Exception ex) {
			log.error("Error saving API status: " + ex.getMessage(), ex);
		}
		log.info("End saveApiFailureStatus method");
	}
	
//	apiStatusServiceImpl.saveApiStatus(Constants.SEARCH_LEAD,
//	response.getStatusCode().value(), phoneNumber, response.getBody(), startTime, endTime, userId,
//	leadId);
	
	public void saveApiStatus(String apiName, int statusCode, String request, String response,
			Timestamp apiStarttime, Timestamp apiEndTime, Long userId, Integer leadId) {
		log.info("Satrt saveApiStatus method");
		LeadAssistAPIStatusEntity apiEntity = new LeadAssistAPIStatusEntity();
		try {
			apiEntity.setApiName(apiName);
            apiEntity.setStatus(statusCode == 200 || statusCode == 202 ? "SUCCESS" : "FAILURE");
            apiEntity.setHttpStatusCode(statusCode);
            apiEntity.setUserId(userId);
            apiEntity.setLeadId(leadId);
            apiEntity.setRequest(objectMapper.writeValueAsString(request));
            apiEntity.setResponse(response);
            apiEntity.setApiStartTime(apiStarttime);
            apiEntity.setApiEndTime(apiEndTime);
            apiEntity.setActive(true);
            apiEntity.setCreatedBy("User");
            apiEntity.setModifiedBy("User");
            apiEntity.setCreatedDate(LocalDateTime.now());
            apiEntity.setModifiedDate(LocalDateTime.now());
 
			commandHandler.save(apiEntity);
		} catch (Exception ex) {
			log.error("Error saving API : " + ex.getMessage(), ex);
			apiEntity.setResponse(null);
			commandHandler.save(apiEntity);
		}
		log.info("End saveApiStatus method");
	}
 
	public void saveApiStatusForInternal(String apiName, int statusCode, Object request, Object response,
			Timestamp apiStarttime, Timestamp apiEndTime, Long customerId, Integer lobId) {
		log.info("Satrt saveApiStatus method");
		try {
			LeadAssistAPIStatusEntity apiEntity = new LeadAssistAPIStatusEntity();
			apiEntity.setApiName(apiName);
			apiEntity.setStatus(statusCode == 200 ? Constants.SUCCESS : Constants.FAILURE);
			apiEntity.setHttpStatusCode(statusCode);
			apiEntity.setUserId(customerId);
			apiEntity.setLeadId(lobId);
			apiEntity.setRequest(objectMapper.writeValueAsString(request));
			apiEntity.setResponse(objectMapper.writeValueAsString(response));
			apiEntity.setApiStartTime(apiStarttime);
			apiEntity.setApiEndTime(apiEndTime);
			apiEntity.setActive(true);
			apiEntity.setCreatedBy("User");
			apiEntity.setModifiedBy("User");
			apiEntity.setCreatedDate(LocalDateTime.now());
			apiEntity.setModifiedDate(LocalDateTime.now());
 
			commandHandler.save(apiEntity);
		} catch (DataAccessException ex) {
			log.error("Error saving API : " + ex.getMessage(), ex);
		} catch (Exception ex) {
			log.error("Error saving API status : " + ex.getMessage(), ex);
		}
		log.info("End saveApiStatus method");
	}
 
	
 
 
}
