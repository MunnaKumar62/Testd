package com.abc.assistedJourney.repository.query;

import org.springframework.data.jpa.repository.JpaRepository;

import com.abc.assistedJourney.entity.LeadCustomer;

public interface LeadCustomerQueryRepository extends JpaRepository<LeadCustomer, Long>{
	
	LeadCustomer findByUniqueId(String uniqueId);

}
