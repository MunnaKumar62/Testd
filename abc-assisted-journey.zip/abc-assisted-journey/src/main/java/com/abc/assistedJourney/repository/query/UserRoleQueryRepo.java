package com.abc.assistedJourney.repository.query;

import com.abc.assistedJourney.entity.Role;
import com.abc.assistedJourney.entity.UserRole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRoleQueryRepo extends JpaRepository<UserRole, Long> {

}
