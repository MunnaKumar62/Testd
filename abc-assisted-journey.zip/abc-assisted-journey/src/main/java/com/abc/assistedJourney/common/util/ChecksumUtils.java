package com.abc.assistedJourney.common.util;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ChecksumUtils {

	//@Value("${otp.service.checksum.password}")
	private String password;

	//@Value("${otp.service.checksum.ivvalue}")
	private String ivvalue;

	//@Value("${otp.service.checksum.saltvalue}")
	private String saltvalue;

	private static final String SECRET_KEY_FACTORY_ALGORITHM = "PBKDF2WithHmacSHA1";
	private static final String SECRET_KEY_SPEC_ALGORITHM = "AES";
	private static final String TRANSAFORMATION = "AES/CBC/PKCS5PADDING";

	public String getChecksum(String strToEncrypt, Date date) throws NoSuchAlgorithmException, InvalidKeySpecException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
		SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyHHmmss");
		String dateTimeStamp = sdf.format(date);
		String saltValue = generateSaltValue(strToEncrypt, saltvalue.trim(), dateTimeStamp);

		SecretKeyFactory factory = SecretKeyFactory.getInstance(SECRET_KEY_FACTORY_ALGORITHM);
		KeySpec spec = new PBEKeySpec(password.trim().toCharArray(), saltValue.getBytes(), 1000, 128);
		SecretKey tmp = factory.generateSecret(spec);

		IvParameterSpec iv = new IvParameterSpec(ivvalue.trim().getBytes());
		SecretKeySpec skeySpec = new SecretKeySpec(tmp.getEncoded(), SECRET_KEY_SPEC_ALGORITHM);
		Cipher cipher = Cipher.getInstance(TRANSAFORMATION);
		cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);

		byte[] encrypted = cipher.doFinal(strToEncrypt.getBytes());
		return Base64.getEncoder().encodeToString(encrypted);
	}

	private String generateSaltValue(String strToEncrypt, String saltValue, String timestamp) {
		List<Integer> position = splitByLength(timestamp, 2);
		StringBuilder key = new StringBuilder();
		int len = strToEncrypt.length();
		for (int x : position) {
			if ((len > x)) {
				if (((x % 2) == 0)) {
					key.append(strToEncrypt.charAt(x));
				} else {
					key.append(strToEncrypt.charAt(len - 1 - x));
				}

			} else {
				int newLen = strToEncrypt.length();
				String newStr = strToEncrypt;
				while (((newLen - 1) < x)) {
					newStr = (newStr + newStr);
					newLen = newStr.length();
				}

				key.append(newStr.charAt(x));
			}

		}
		return ((key.toString().substring(0, (position.size() / 2))) + saltValue
				+ (key.toString().substring((position.size() / 2))));
	}

	public String getCurrentTimeStamp(Date date) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a");
		return simpleDateFormat.format(date);
	}

	private List<Integer> splitByLength(String x, int maxLength) {
		List<Integer> a = new ArrayList<>();
		for (int i = 0; i < x.length(); i += 2) {
			if ((i + 2) < x.length()) {
				a.add(Integer.parseInt(x.substring(i, maxLength)) % 10);
			} else {
				a.add(Integer.parseInt(x.substring(i)) % 10);
			}
			maxLength = maxLength + 2;
		}
		return a;
	}
}
