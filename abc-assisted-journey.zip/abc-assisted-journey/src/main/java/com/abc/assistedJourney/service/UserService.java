
package com.abc.assistedJourney.service;

import com.abc.assistedJourney.entity.User;
import com.abc.assistedJourney.model.response.UserDetailsResponse;
import com.abc.assistedJourney.model.response.UserLoginHistoryResponse;
import com.abc.assistedJourney.model.request.LeadAssisHelpRequest;
import com.abc.assistedJourney.model.response.UserResponse;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

public interface UserService{

    List<UserLoginHistoryResponse> getUserHistoryResponse(String userId) throws Exception;

    // Method to create a user and assign role with permissions
    User createUserWithRoleAndPermissions(String username, String email, String password, String roleName, Map<String, List<String>> modulePermissions);

    UserResponse getProfile(String userID) throws Exception;

    String uploadImage(MultipartFile file) throws Exception;

	String leadAssisHelp(LeadAssisHelpRequest leadAssisHelp) throws Exception;

	String removeProfileImage(Long id) throws Exception;

    List<UserDetailsResponse> getAllUsers(String id);

}
