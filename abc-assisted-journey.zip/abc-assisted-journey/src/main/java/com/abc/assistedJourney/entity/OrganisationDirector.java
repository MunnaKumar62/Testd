package com.abc.assistedJourney.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "t_assist_organisation_director")
public class OrganisationDirector {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String fullName;
    private String mobile;
    private String email;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private UserDetails userDetails;
}