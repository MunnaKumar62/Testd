package com.abc.assistedJourney.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ObjRequest {

    @JsonProperty("MobileNo")
    private String mobileNo;

    @JsonProperty("ClientIPAddress")
    private String clientIPAddress;

    @JsonProperty("DeviceID")
    private String deviceID;

    @JsonProperty("OS")
    private String os;

    @JsonProperty("IMEI")
    private String imei;

    @JsonProperty("UDP")
    private String udp;

    @JsonProperty("UDP1")
    private String udp1;

    @JsonProperty("UDP2")
    private String udp2;

    @JsonProperty("UDP3")
    private String udp3;

    @JsonProperty("UDP4")
    private String udp4;

    @JsonProperty("UDP5")
    private String udp5;

    @JsonProperty("MethodName")
    private String methodName;

    @JsonProperty("ModuleName")
    private String moduleName;

    @JsonProperty("AuthCode")
    private String authCode;

    @JsonProperty("Source")
    private String source;

    @JsonProperty("LogRefId")
    private String logRefId;

    @JsonProperty("ADID")
    private String adid;

    @JsonProperty("Email")
    private String email;
}