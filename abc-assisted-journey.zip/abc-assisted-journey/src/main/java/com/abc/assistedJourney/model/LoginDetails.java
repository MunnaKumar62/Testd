package com.abc.assistedJourney.model;

import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class LoginDetails {
	
	private String mobileNo;
	private String email;
	private String adid;
	private String password;
	private String tokenID;
}
