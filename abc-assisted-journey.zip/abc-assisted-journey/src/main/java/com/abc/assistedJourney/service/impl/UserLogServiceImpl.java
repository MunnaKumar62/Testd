package com.abc.assistedJourney.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
<<<<<<< HEAD
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.abc.assistedJourney.common.constants.Constants;
import com.abc.assistedJourney.common.util.CommonUtil;
import com.abc.assistedJourney.entity.LoginHistory;
import com.abc.assistedJourney.entity.User;
import com.abc.assistedJourney.exception.CustomException;
import com.abc.assistedJourney.model.request.UserLogRequestDTO;
import com.abc.assistedJourney.model.response.UserLogResponseDTO;
import com.abc.assistedJourney.repository.command.UserLogRepository;
import com.abc.assistedJourney.repository.command.UserRepository;
import com.abc.assistedJourney.service.UserLogService;
import com.abc.core.common.exception.CommonExceptionHandler;
import com.abc.core.common.exception.InternalException;

import lombok.extern.log4j.Log4j2;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

@Log4j2
@Service
public class UserLogServiceImpl implements UserLogService {

    @Autowired
    private UserLogRepository userLogRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private CommonExceptionHandler handler;

    @Override
    public List<UserLogResponseDTO> getUserLogs(UserLogRequestDTO request, Pageable pageable) throws Exception {
        Timestamp startTime = CommonUtil.getCurrentTimestamp();
        ResponseEntity<UserLogResponseDTO> externalApiResponse = null; // Renamed variable
        try {
            String externalAPI = "https://mockapi.example.com/getlogHistory";

            User user = userRepository.findById(request.getUserId())
                    .orElseThrow(() -> new CustomException("AJ2000", Constants.GET_USER_LOGS + ""));
            // Prepare headers for the external API call
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            // Create the request entity for the external API
            HttpEntity<UserLogRequestDTO> entity = new HttpEntity<>(request, headers);
//	        externalApiResponse = restTemplate.exchange(externalAPI, HttpMethod.POST, entity, UserLogResponseDTO.class);
//	        if (externalApiResponse == null || externalApiResponse.getBody() == null) {
//	            throw new CustomException("AJ2001", Constants.GET_USER_LOGS + "");
//	        UserLogResponseDTO UserLogResponseDTO = response.getBody();

            Page<LoginHistory> logsPage = userLogRepository.findByUserAndTimestampBetween(user, request.getStartDate(),
                    request.getEndDate(), pageable);

            return logsPage.stream().map(log -> {
                UserLogResponseDTO logResponse = new UserLogResponseDTO(); // Renamed variable here
//		        logResponse.setTimestamp(log.getTimestamp());
//		        logResponse.setUserId(log.getUser().getId());
//		        logResponse.setClientIp(log.getClientIp());
//		        logResponse.setModule(log.getModule());
//		        logResponse.setSessionId(log.getSessionId());

                // Set dummy data for testing
                logResponse.setTimestamp(LocalDateTime.now()); // Random timestamp up to 10 days ago
                logResponse.setUserId(121L); // Use the actual user ID
                logResponse.setClientIp("321"); // Mock client IP
                logResponse.setModule("122"); // Mock module name
                logResponse.setSessionId("343"); // Mock session ID
                return logResponse;
            }).collect(Collectors.toList());

        }catch (CustomException ex) {
            log.error(ex.getMessage());
            handler.handleException(ex, Constants.GET_USER_LOGS, "");
        } catch (HttpClientErrorException | HttpServerErrorException ex) {
            log.error("Exception in external API call: " + ex.getResponseBodyAsString());
            handler.handleException(ex, Constants.GET_USER_LOGS, "");
        } catch (Exception ex) {
            log.error("Unexpected exception: " + ex.getMessage());
            handler.handleException(new InternalException("AJ2100", ex), Constants.GET_USER_LOGS, "");
        }
        return null;

    }
}
=======
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.abc.assistedJourney.entity.UserLog;
import com.abc.assistedJourney.model.request.LogRequestDTO;
import com.abc.assistedJourney.model.response.LogResponseDTO;
import com.abc.assistedJourney.repository.command.UserLogRepository;
import com.abc.assistedJourney.service.UserLogService;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserLogServiceImpl implements UserLogService {

	@Autowired
	private UserLogRepository userLogRepository;

	@Override
    public Page<LogResponseDTO> getUserLogs(String userId, LogRequestDTO requestDTO, Pageable pageable) {
		/*
		 * List<UserLog> logs = userLogRepository.findByUserIdAndTimestampBetween(
		 * requestDTO.getSelectedUserId(), requestDTO.getStartDate(),
		 * requestDTO.getEndDate() );
		 */

	    List<LogResponseDTO> responseDTOs = new ArrayList<>();

      //  List<LogResponseDTO> responseDTOs = logs.stream().map(log -> {
            LogResponseDTO dto = new LogResponseDTO();
            dto.setTimestamp(LocalDateTime.now());
            dto.setClientIp("321");
              dto.setModule("122");
              dto.setSessionId("343");
              dto.setTimestamp(LocalDateTime.now());
             dto.setUserId("121");
            responseDTOs.add(dto);
//            return responseDTOs;
//        }).collect(Collectors.toList());

	return new PageImpl<>(responseDTOs,pageable,responseDTOs.size());
}}
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
