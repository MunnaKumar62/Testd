package com.abc.assistedJourney.entity;

import jakarta.persistence.GenerationType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.GeneratedValue;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import jakarta.persistence.*;

import java.util.HashSet;
import java.util.Set;


@Entity
@Table(name = "t_assist_modules")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Module {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String moduleName;

    // A role can have multiple modules
    @ManyToOne
    @JoinColumn(name = "role_id")
    private Role role;

    // A module can have multiple submodules
    @OneToMany(mappedBy = "module", cascade = CascadeType.ALL)
    private Set<Submodule> submodules = new HashSet<>();
}
