package com.abc.assistedJourney.entity;

import jakarta.persistence.GenerationType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.GeneratedValue;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import jakarta.persistence.*;

@Entity
@Table(name = "t_assist_submodules")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Submodule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String submoduleName;

    // A module can have multiple submodules
    @ManyToOne
    @JoinColumn(name = "module_id")
    private Module module;
}
