package com.abc.assistedJourney.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.abc.assistedJourney.entity.User;
import com.abc.assistedJourney.repository.query.UserRepositoryQuery;
import com.abc.assistedJourney.service.AssistedJourneyService;

@Service

public class AssistedJourneyServiceImpl implements AssistedJourneyService{

	@Autowired
	UserRepositoryQuery assistedJourneyRepository;

	@Autowired
	private RestTemplate restTemplate;
	
	 private static final String EXTERNAL_API_URL = "https://api.example.com/user/{userID}";

	
	

}
