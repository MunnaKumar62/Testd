package com.abc.assistedJourney.entity;

import java.time.LocalDateTime;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "t_assist_organisation_agent")
public class OrganisationAgent {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String mobile;
    private String email;
    private String onboardedBy;
    private LocalDateTime onboardedDate;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private UserDetails userDetails;
}