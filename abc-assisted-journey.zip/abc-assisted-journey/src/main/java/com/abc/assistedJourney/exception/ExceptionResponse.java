package com.abc.assistedJourney.exception;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ExceptionResponse {
    private final Integer code;
    private final String reason;
    private final String errorCode;
    private final String errorMessage;
    private final String message;
    private final String errorType;
}
