package com.abc.assistedJourney.cache;


import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;


@Service
@Slf4j
public class SampleCache {
    /*
    private final String className = "[" + this.getClass().getSimpleName() + "]";

    private static final String HOME_LOAN_CACHE = "HomeLoan";
    private static final String CACHE_PARAM_LOB = "LobMasterDetails";
    private static final String CACHE_PARAM_CALCULATOR = "CalculatorDetails";
    private static final String CACHE_PARAM_SALARY_BANK_MASTER = "SalaryBankMasterDetails";
    private static final String CACHE_PARAM_OTHER_SALARY = "OtherSalary";
    private static final String CACHE_PARAM_LOAN_COMPANY = "LoanCompanyName";
    private static final String CACHE_PARAM_CONFIG_MASTER = "ConfigMaster";


    @Autowired
    private QueryHandler;

    @Autowired
    GenericCacheService;

    public List<LobMaster> getLobMasterDetailsFromCache() {
     return  genericCacheService.getFromCacheOrDb(
             HOME_LOAN_CACHE,
             CACHE_PARAM_LOB,
             new TypeReference<List<LobMaster>>() {},
             queryHandler::getLobMasterByDesc);
    }

    public List<HomeLoanPercentAllocation> getCalculatorDetailsServiceFromCache() {
        log.info("Start of getCalculatorDetailsService");
        return genericCacheService.getFromCacheOrDb(
                HOME_LOAN_CACHE,
                CACHE_PARAM_CALCULATOR,
                new TypeReference<List<HomeLoanPercentAllocation>>() {
                },
                queryHandler::findAll
        );
    }

    public void updateHomeLoanCache(ReferralEmployee employee) throws JsonProcessingException, RedisException {
        String cacheParam = "REFERRAL_EMP_LIST_" + employee.getCustomerId() + "_" + employee.getLobId();
        String cacheParamreferal = "REFERRAL_EMP_LIST_" +  employee.getCustomerId() + "_" + employee.getLobId();

        genericCacheService.updateCache(HOME_LOAN_CACHE, cacheParam, employee, ReferralEmployee.class);
        genericCacheService.updateCache(HOME_LOAN_CACHE, cacheParamreferal, employee, ReferralEmployee.class);

    }

     */
}
