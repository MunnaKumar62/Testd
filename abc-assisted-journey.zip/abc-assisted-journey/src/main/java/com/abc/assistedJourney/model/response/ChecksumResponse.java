package com.abc.assistedJourney.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ChecksumResponse {
	@JsonProperty("ReturnMessage")
    private String returnMessage;

    @JsonProperty("ReturnCode")
    private String returnCode;

    @JsonProperty("Checksum")
    private String checksum;

    @JsonProperty("UDP")
    private String udp;
}
