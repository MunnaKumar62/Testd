package com.abc.assistedJourney.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.assistedJourney.entity.OrganisationDirector;
import com.abc.assistedJourney.entity.ReportingManager;
import com.abc.assistedJourney.entity.UserDetails;
import com.abc.assistedJourney.model.response.UserDetailsResponseDTO;
import com.abc.assistedJourney.repository.command.UserDetailsRepository;
import com.abc.assistedJourney.service.UserDetailsService;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {
    @Autowired
    private UserDetailsRepository userDetailsRepository;

    @Override
    public UserDetailsResponseDTO getUserDetailsByUniqueId(String uniqueId, String constitutionType) {
        UserDetailsResponseDTO responseDTO = new UserDetailsResponseDTO();

        // Return dummy data for testing purposes
<<<<<<< HEAD
        if (uniqueId.equals("dummyEmployeeId")) {
            // Dummy User Details
            UserDetails dummyUser = new UserDetails();
            dummyUser.setEmployeeId("dummyEmployeeId");
=======
        if (uniqueId.equals("12")) {
            // Dummy User Details
            UserDetails dummyUser = new UserDetails();
            dummyUser.setEmployeeId("121");
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
            dummyUser.setName("John Doe");
            dummyUser.setRole("Sales Manager");
            dummyUser.setEmail("john.doe@example.com");
            dummyUser.setAddress("123 Main St, Springfield");
            dummyUser.setGender("Male");
            dummyUser.setDateOfBirth(LocalDate.of(1990, 1, 1));
            dummyUser.setZone("Springfield");
            dummyUser.setBranch("Sales");
            dummyUser.setDateOfJoining(LocalDate.of(2022, 1, 1));
            dummyUser.setMobile("+1 234 567 8900");
            dummyUser.setDsaCode("DUMMY123");
            dummyUser.setConstitutionType("Individual");
            dummyUser.setOnboardedBy("Admin");
            dummyUser.setOnboardedDate(LocalDateTime.now());
            dummyUser.setCurrentAddress("456 Elm St, Springfield");
            dummyUser.setPermanentAddress("456 Elm St, Springfield");
            dummyUser.setNameOfOrganisation("Dummy Org");
            dummyUser.setOrganisationType("LLC");
            dummyUser.setOfficeAddress("789 Maple St, Springfield");
            dummyUser.setDateOfIncorporation(LocalDate.of(2015, 5, 15));

            // Dummy Reporting Manager
            ReportingManager reportingManager = new ReportingManager();
            reportingManager.setSales("Sales");
            reportingManager.setDivision("Retail");
            reportingManager.setReportingTo("Jane Smith");
            reportingManager.setReportingManagerRole("Senior Manager");
            reportingManager.setReportingManagerName("Jane Smith");
            reportingManager.setEmailId("jane.smith@example.com");
            reportingManager.setContactNumber("+1 987 654 3210");
            reportingManager.setDepartment("Sales");
            reportingManager.setBranch("Main");

            responseDTO.setBasicDetails(dummyUser);
            responseDTO.setReportingManagerDetails(reportingManager);
            return responseDTO;
        }

        if (uniqueId.equals("dummyDsaCode") && "Non Individual".equals(constitutionType)) {
            // Dummy Organisation Details
            UserDetails dummyUser = new UserDetails();
<<<<<<< HEAD
            dummyUser.setDsaCode("dummyDsaCode");
=======
            dummyUser.setDsaCode("234");
>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
            dummyUser.setConstitutionType("Non Individual");
            dummyUser.setNameOfOrganisation("Dummy Solutions");
            dummyUser.setOrganisationType("Partnership");
            dummyUser.setMobile("+1 234 567 8900");
            dummyUser.setEmail("info@dummysolutions.com");
            dummyUser.setOfficeAddress("123 Business Rd, Springfield");
            dummyUser.setCurrentAddress("123 Business Rd, Springfield");
            dummyUser.setPermanentAddress("123 Business Rd, Springfield");
            dummyUser.setDateOfIncorporation(LocalDate.of(2010, 1, 1));
            dummyUser.setOnboardedBy("Admin");
            dummyUser.setOnboardedDate(LocalDateTime.now());

            // Dummy Organisation Director
            OrganisationDirector director = new OrganisationDirector();
            director.setFullName("Alice Johnson");
            director.setMobile("+1 234 567 8901");
            director.setEmail("alice.johnson@example.com");

            responseDTO.setBasicDetails(dummyUser);
            responseDTO.setOrganisationDirectors(List.of(director));
            return responseDTO;
        }

        // Return dummy data for other cases as necessary
        throw new RuntimeException("User not found");
    }
}

// Commented for Dummy Code...
/*
 * @Override public UserDetailsResponseDTO getUserDetailsByUniqueId(String
 * uniqueId, String constitutionType) { UserDetailsResponseDTO responseDTO = new
 * UserDetailsResponseDTO();
 *
 * // Check if uniqueId is an Employee ID or DSA Code Optional<UserDetails>
 * userDetailsOptional = userDetailsRepository.findByEmployeeId(uniqueId); if
 * (userDetailsOptional.isPresent()) { UserDetails user =
 * userDetailsOptional.get(); responseDTO.setBasicDetails(user); // Set related
 * details like ReportingManager, Organisation Directors, etc. return
 * responseDTO; }
 *
 * userDetailsOptional =
 * userDetailsRepository.findByDsaCodeAndConstitutionType(uniqueId,
 * constitutionType); if (userDetailsOptional.isPresent()) { UserDetails user =
 * userDetailsOptional.get(); responseDTO.setBasicDetails(user); // Set related
 * details here as well return responseDTO; }
 *
 * throw new RuntimeException("User not found"); }
 */