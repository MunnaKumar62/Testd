package com.abc.assistedJourney.model.response;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserResponse {

	private Long id;

	private String username;
	private String email;
	private String employeeId;
	private String role;
	private String department;
	private String division;
	private String address;
	private String gender;
	private LocalDate dateOfBirth;
	private String manager;
	private String phoneNumber;
	private String mobileNumber;
}
