package com.abc.assistedJourney.service.impl;

import com.abc.assistedJourney.entity.*;
import com.abc.assistedJourney.entity.Module;
import com.abc.assistedJourney.handler.CommandHandler;
import com.abc.assistedJourney.handler.QueryHandler;
import com.abc.assistedJourney.repository.command.RoleRepository;
import com.abc.assistedJourney.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class RoleServiceImpl implements RoleService {

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    QueryHandler queryHandler;

    @Autowired
    CommandHandler commandHandler;

    @Override
    public List<Role> getAllRoles() {
      //  return queryHandler.getAllRole();
        return  getMockRole();
    }

    private List<Role> getMockRole() {
        // Hardcoding some role values for testing purposes

        List<Role> roles = new ArrayList<>();

        // First role: ADMIN
        Role adminRole = new Role();
        adminRole.setId(1L);
        adminRole.setRoleName("ADMIN");
        adminRole.setReportsTo("CEO");
        adminRole.setCreatedTimeStamp("2024-10-25T10:00:00");
        adminRole.setStatus("Active");

        // Adding permissions for ADMIN
        Permission adminPermission1 = new Permission();
        adminPermission1.setId(1L);
        adminPermission1.setPermissionName("READ_PRIVILEGES");

        Permission adminPermission2 = new Permission();
        adminPermission2.setId(2L);
        adminPermission2.setPermissionName("WRITE_PRIVILEGES");

        adminRole.getPermissions().add(adminPermission1);
        adminRole.getPermissions().add(adminPermission2);

        // Adding modules for ADMIN
        Module adminModule1 = new Module();
        adminModule1.setId(1L);
        adminModule1.setModuleName("Dashboard");

        Module adminModule2 = new Module();
        adminModule2.setId(2L);
        adminModule2.setModuleName("User Management");

        adminRole.getModules().add(adminModule1);
        adminRole.getModules().add(adminModule2);

        // Adding services for ADMIN
        Services adminService1 = new Services();
        adminService1.setId(1L);
        adminService1.setServiceName("Service A");

        Services adminService2 = new Services();
        adminService2.setId(2L);
        adminService2.setServiceName("Service B");

        adminRole.getServices().add(adminService1);
        adminRole.getServices().add(adminService2);

        // Second role: USER
        Role userRole = new Role();
        userRole.setId(2L);
        userRole.setRoleName("USER");
        userRole.setReportsTo("ADMIN");
        userRole.setCreatedTimeStamp("2024-10-24T11:00:00");
        userRole.setStatus("Active");

        // Adding permissions for USER
        Permission userPermission1 = new Permission();
        userPermission1.setId(3L);
        userPermission1.setPermissionName("READ_PRIVILEGES");

        userRole.getPermissions().add(userPermission1);

        // Adding modules for USER
        Module userModule1 = new Module();
        userModule1.setId(3L);
        userModule1.setModuleName("Dashboard");

        userRole.getModules().add(userModule1);

        // Adding services for USER
        Services userService1 = new Services();
        userService1.setId(3L);
        userService1.setServiceName("Service C");

        userRole.getServices().add(userService1);

        // Adding roles to the list
        roles.add(adminRole);
        roles.add(userRole);

        return roles;
    }
}