package com.abc.assistedJourney.repository.query;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.abc.assistedJourney.entity.Lead;

@Repository
public interface LeadQueryRepository extends JpaRepository<Lead, Long> {
	
	Lead findByMobileNumber(String mobileNumber);
}
