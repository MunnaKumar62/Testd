package com.abc.assistedJourney.exception;

import org.springframework.http.HttpStatusCode;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InternalException extends RuntimeException {

	private static final long serialVersionUID = 4087930070289795747L;

	private String errorCode;
	private String errorMessage;
	private Integer code;
	private String reason;
	private String errorType;

	public InternalException() {
		super();
	}

	public InternalException(Throwable cause) {
		super(cause);
	}

	public InternalException(String errorCode) {
		super();
		this.errorCode = errorCode;
	}
	
	public InternalException(String errorCode, String errorMessage) {
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}
	
	public InternalException(String errorCode, String errorMessage, Integer code, String reason) {
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.code = code;
		this.reason = reason;
	}

	public InternalException(String errorCode2, String errorType, String string, String message) {
		super();
		this.code = code;
		this.errorCode = errorCode2;
		this.errorType = errorType;
		this.errorMessage = message;

	}

}
