package com.abc.assistedJourney.repository.command;

import org.springframework.data.jpa.repository.JpaRepository;

import com.abc.assistedJourney.entity.UploadImage;

public interface ImageRepository extends JpaRepository<UploadImage, Long> {

}
