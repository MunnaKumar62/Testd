package com.abc.assistedJourney.model.request;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class LogRequestDTO {
    private String loggedInUserId;
    private String selectedUserId;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
}
