package com.abc.assistedJourney.entity;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;


@Data
@Entity
@Table(name = "t_assist_lead_customer")
public class LeadCustomer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String fullName;
 	private String mobileNumber;
 	private String emailId;
 	private LocalDate dob;
 	private String channelType;
 	private String uniqueId;
 	private boolean isConsent;


}
