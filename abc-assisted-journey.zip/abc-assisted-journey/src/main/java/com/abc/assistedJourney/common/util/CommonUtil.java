package com.abc.assistedJourney.common.util;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.IntStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.validation.FieldError;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.abc.assistedJourney.common.constants.Constants;
import com.abc.assistedJourney.common.model.ErrorResponse;
import com.abc.assistedJourney.common.model.Errors;
import com.abc.assistedJourney.common.model.SuccessResponse;
import com.abc.assistedJourney.entity.CustomerDetails;
import com.abc.assistedJourney.exception.ExternalException;
import com.abc.assistedJourney.exception.PartnerError;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component
public class CommonUtil {

	private static final String ZONE = "Asia/Kolkata";

	public static Timestamp getCurrentTimestamp() {
		return Timestamp.valueOf(LocalDateTime.now(ZoneId.of(ZONE)));
	}

	public static SuccessResponse getSuccessResponse(String code, String message, Object data) {

		SuccessResponse successResponse = new SuccessResponse();
		successResponse.setTimestamp(LocalDateTime.now());
		successResponse.setStatus(Constants.SUCCESS);
		successResponse.setCode(code);
		successResponse.setMessage(message);
		successResponse.setData(data);
		return successResponse;
	}

	public static SuccessResponse getErrorResponse(String errorCode, String message, Object data) {
		SuccessResponse errorResponse = new SuccessResponse();
		errorResponse.setCode(errorCode);
		errorResponse.setMessage(message);
		errorResponse.setData(data); // Optionally, you can set data to null for error responses
		return errorResponse;
	}

}
