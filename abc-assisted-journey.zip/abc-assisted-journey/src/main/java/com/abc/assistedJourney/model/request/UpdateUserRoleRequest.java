package com.abc.assistedJourney.model.request;

import com.abc.assistedJourney.entity.Role;
import lombok.Data;

import java.util.Set;

@Data
public class UpdateUserRoleRequest {
    private Long loggedInUserId;
    private Role updatedRole;

}
