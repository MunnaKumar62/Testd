package com.abc.assistedJourney.handler;

import com.abc.assistedJourney.entity.*;
import com.abc.assistedJourney.repository.command.ImageRepository;
import com.abc.assistedJourney.repository.command.LeadAssisHelpRepository;
import com.abc.assistedJourney.repository.command.RoleStatusRepository;
import com.abc.assistedJourney.repository.command.UserLoginHistoryRepo;
import com.abc.assistedJourney.repository.command.AssistedJourneyApiStatusRepository;
import com.abc.assistedJourney.repository.command.HelpIssueFilterRepository;
import com.abc.assistedJourney.repository.command.LeadCustomerRepository;
import com.abc.assistedJourney.repository.command.LeadRepository;
import com.abc.assistedJourney.repository.command.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class CommandHandler {

	@Autowired
	private UserRepository userRepository;

    @Autowired
    private UserLoginHistoryRepo userLoginHistoryRepo;

    @Autowired
    private RoleStatusRepository roleStatusRepository;

    public void save(UserLoginHistory userLoginHistory){
        userLoginHistoryRepo.save(userLoginHistory);
    }
    public RoleStatus createRoleStatus(RoleStatus roleStatus) {
        return roleStatusRepository.save(roleStatus);
    }

    @Autowired
    private LeadRepository leadRepository;

    @Autowired
    private LeadCustomerRepository leadcustomerRepository;
	@Autowired
	private ImageRepository imageRepository;
    @Autowired
    private HelpIssueFilterRepository helpIssueFilterRepository;

    @Autowired
    private AssistedJourneyApiStatusRepository apiStatusRepository;

    public void saveLead(Lead lead) {
		leadRepository.save(lead);
	}

    public void saveLeadCustomer(LeadCustomer leadCustomer) {
    	leadcustomerRepository.save(leadCustomer);
	}
	@Autowired
	private LeadAssisHelpRepository leadAssisHelpRepository;

	public User saveUser(User user) {
		return userRepository.save(user);
	}

    public void saveHelpIssueFilter(HelpIssueFilter helpIssueFilter) {
    	helpIssueFilterRepository.save(helpIssueFilter);
	}
	public UploadImage uploadImage(UploadImage uploadImage) {
        return imageRepository.save(uploadImage);
    }
    public void save(LeadAssistAPIStatusEntity apiEntity) {
		// TODO Auto-generated method stub
		apiStatusRepository.save(apiEntity);
	}
	public LeadAssisHelpEntity saveLeadAssisHelp(LeadAssisHelpEntity leadAssisHelp) {
		return leadAssisHelpRepository.save(leadAssisHelp);
	}

	public void removeProfileImage(Long id) {
		imageRepository.deleteById(id);

	}

}
