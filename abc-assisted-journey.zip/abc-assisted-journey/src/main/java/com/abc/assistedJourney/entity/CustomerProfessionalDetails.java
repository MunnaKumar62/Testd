package com.abc.assistedJourney.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "t_customer_professional_details")
public class CustomerProfessionalDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5171932730057109047L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "customer_professional_id")
	private Long customerProfessionalId;

	@ManyToOne
	@JsonBackReference
	@JoinColumn(name = "customer_id")
	private CustomerDetails customerDetails;

	@Column(name = "employment_type", length = 20)
	@NotBlank(message = "{HL4114}")
	private String employmentType;

	@Column(name = "employer_id", length = 20)
	@NotBlank(message = "{HL4115}")
	private String employerId;

	@Column(name = "annual_income")
	@NotNull(message = "{HL4116}")
	// @DecimalMin(value = "1.0", message = "{HL4116}")
	private Double annualIncome;

	@Column(name = "total_work_experience")
	@NotNull(message = "{HL4117}")
//	@Min(value = 1, message = "{HL4117}")
	private Integer totalWorkExperience;
	
	@Column(name = "exp_in")
	private String expIn = "Y";

	@Column(name = "created_by", length = 60)
	private String createdBy;

	@Column(name = "created_date")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime createdDate;

	@Column(name = "modified_by", length = 60)
	private String modifiedBy;

	@Column(name = "modified_date")
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime modifiedDate;

	@Column(name = "status")
	private boolean status;
	
	@Column(name = "active")
	private boolean active;
	
}
