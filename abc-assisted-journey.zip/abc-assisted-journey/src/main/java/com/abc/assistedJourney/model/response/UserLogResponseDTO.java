package com.abc.assistedJourney.model.response;


import java.time.LocalDateTime;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class UserLogResponseDTO {
    private LocalDateTime timestamp;
    private Long userId;  // Changed to Long to match User entity
    private String clientIp;
    private String module;
    private String sessionId;
}