package com.abc.assistedJourney.model.request;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserLogRequestDTO {
    private Long userId;  // Changed to Long for User entity
    private LocalDateTime startDate;
    private LocalDateTime endDate;

    // Getters and Setters
}