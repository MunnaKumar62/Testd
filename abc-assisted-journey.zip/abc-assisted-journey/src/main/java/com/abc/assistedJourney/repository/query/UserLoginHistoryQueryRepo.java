package com.abc.assistedJourney.repository.query;

import com.abc.assistedJourney.entity.User;
import com.abc.assistedJourney.entity.UserLoginHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserLoginHistoryQueryRepo extends JpaRepository<UserLoginHistory, Long> {

    List<UserLoginHistory> findByUser(User user);
}