package com.abc.assistedJourney.repository.query;

import org.springframework.data.jpa.repository.JpaRepository;

import com.abc.assistedJourney.entity.HelpIssueFilter;


public interface HelpIssueFilterQueryRepository extends JpaRepository<HelpIssueFilter, Integer> {

}
