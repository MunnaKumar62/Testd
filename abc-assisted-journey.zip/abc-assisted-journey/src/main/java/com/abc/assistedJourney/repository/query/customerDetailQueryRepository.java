package com.abc.assistedJourney.repository.query;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.abc.assistedJourney.entity.CustomerDetails;

@Repository
public interface customerDetailQueryRepository extends JpaRepository<CustomerDetails, Long>{

}
