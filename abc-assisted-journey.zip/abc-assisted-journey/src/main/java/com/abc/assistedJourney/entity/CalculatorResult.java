package com.abc.assistedJourney.entity;

import jakarta.persistence.Lob;
import jakarta.persistence.Column;
import jakarta.persistence.GenerationType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.GeneratedValue;
import java.time.LocalDateTime;

@Entity
@Table(name = "calculator_results")
public class CalculatorResult {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Lob
    private String parameters;

    @Lob
    private String result;

    @ManyToOne
    @JoinColumn(name = "customer_id")
    private CustomerDetails customer;

    @ManyToOne
    @JoinColumn(name = "generated_by")
    private User generatedBy;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

}

