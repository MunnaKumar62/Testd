package com.abc.assistedJourney.model.response;

import com.abc.assistedJourney.entity.User;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class UserRoleResponse {

    @JsonProperty("userId")
    private String userId;

    @JsonProperty("roles")
    private List<String> roles;

    @JsonProperty("timestamp")
    private LocalDateTime timestamp;

    @JsonProperty("viewLogsLink")
    private String viewLogsLink;
}

