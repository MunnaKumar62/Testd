package com.abc.assistedJourney.repository.command;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

<<<<<<< HEAD
import com.abc.assistedJourney.entity.LoginHistory;
import com.abc.assistedJourney.entity.User;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;

@Repository
public interface UserLogRepository extends JpaRepository<LoginHistory, Long> {
    Page<LoginHistory> findByUserAndTimestampBetween(User user, LocalDateTime startDate, LocalDateTime endDate, Pageable pageable);
}
=======
import com.abc.assistedJourney.entity.UserLog;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface UserLogRepository extends JpaRepository<UserLog, Long> {
    List<UserLog> findByUserIdAndTimestampBetween(String userId, LocalDateTime startDate, LocalDateTime endDate);
}

>>>>>>> f5545a1dc67ac28cbc5f9035e9dd1818257b2b26
