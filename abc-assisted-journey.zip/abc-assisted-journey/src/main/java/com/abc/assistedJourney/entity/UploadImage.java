package com.abc.assistedJourney.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Table(name = "t_assist_upload_image")
@Entity
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class UploadImage {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String filename;
	private String filepath;
	private LocalDateTime modifiedDate;
	private LocalDateTime createdDate;
	
}
