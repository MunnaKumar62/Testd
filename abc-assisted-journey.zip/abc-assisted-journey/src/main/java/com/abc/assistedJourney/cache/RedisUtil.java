package com.abc.assistedJourney.cache;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Slf4j
@Data
public class RedisUtil {

    @Value("${retry.max.attempts}")
    private int maxRetryAttempts;

    @Value("${retry.delay.ms}")
    private long retryDelayMs;

    public static final long CACHE_TTL = 30;

}
