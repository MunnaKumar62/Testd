package com.abc.assistedJourney.entity;

import java.io.File;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "t_assist_help")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LeadAssisHelpEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String raiseAnIssue;
	private String subject;
	private String description;
	//private List<MultipartFile> attacheFile;
	@Lob
    private byte[] data;
	
	private String filename;
	private String filepath;

}
