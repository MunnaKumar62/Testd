package com.abc.assistedJourney;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsisstedJourneyApplicationTests {

}
